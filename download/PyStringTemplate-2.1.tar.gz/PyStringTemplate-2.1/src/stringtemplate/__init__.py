
__all__ = ['language']

from StringTemplate import *
