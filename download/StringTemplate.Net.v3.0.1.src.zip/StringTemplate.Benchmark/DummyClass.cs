namespace StringTemplate.Benchmark
{
	using System;

	/// <summary>
	/// A Dummy Class just to hold a Main() method so the project would build.
	/// A placeholder until the various benchmarks are retrofitted into this
	/// project.
	/// </summary>
	public class DummyClass
	{
		public static void Main(string[] args)
		{
		}
	}
}
