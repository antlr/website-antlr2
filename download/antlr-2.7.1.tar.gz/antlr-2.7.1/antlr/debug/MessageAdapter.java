package antlr.debug;

public class MessageAdapter implements MessageListener {


	public void doneParsing(TraceEvent e) {}
	public void refresh() {}
	public void reportError(MessageEvent e) {}
	public void reportWarning(MessageEvent e) {}
}