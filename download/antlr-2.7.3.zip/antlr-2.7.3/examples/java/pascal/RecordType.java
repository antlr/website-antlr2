import java.io.*;

public class RecordType extends TypeSpecifier implements Serializable {
}
