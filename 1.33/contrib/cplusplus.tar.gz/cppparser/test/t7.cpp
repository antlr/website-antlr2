f(int farg)
{
	try {
		// ...
		throw "help!";
	}
	catch(char *p) {
		// handle things
	}
}

class Overflow {
public:
	Overflow(char, double, double);
};

void g(double x)
{
	try {
		throw Overflow('+',x,3.45);
	}
	catch(Overflow& oo) {
		// handle things
	}
}
