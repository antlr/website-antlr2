/* Test scoping of parameters */

f()
{
	int g(int a);
}
