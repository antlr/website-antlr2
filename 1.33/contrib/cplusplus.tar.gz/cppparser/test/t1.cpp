class A {
	int i;
};

A::A() {}

class T {
	int i;
	foo();
	T();
	T() { int i = 3; }
	~T();
	~T(int i) { int i = 3; }
public:
	typedef int INT;

	INT a;
	int fu() {}
	int bar() {}
	void operator+(int i) {int ee = i;}
};

T::T() {float q;}

T::foo() {}

void T::operator+() {}

T a, b=3;
