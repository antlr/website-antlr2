class Overflow {
public:
        Overflow(char, double, double);
};

