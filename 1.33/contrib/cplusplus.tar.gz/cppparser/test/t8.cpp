template<class T> class A {
	int i;
	float a;
};
