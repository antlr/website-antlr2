class T;

class A {
	inline operator T*() const;
};

inline A::operator T*() const
{
}

