typedef unsigned bool;

class A23456789012345WOHandle;
class A23456789012345;
class A23456789012345Handle
{
  public:
    A23456789012345Handle (   A23456789012345 * const p = 0 );
    
    A23456789012345Handle ( const  A23456789012345Handle & from );
    ~A23456789012345Handle ();
    
    const A23456789012345Handle& operator=(const A23456789012345Handle& source);

    A23456789012345Handle & operator= (  A23456789012345 *const newObject);
    
    operator   A23456789012345 *() const;
    
    operator   A23456789012345 *();
    
    A23456789012345 & operator *();
    
    const   A23456789012345 & operator *() const;
    A23456789012345 * operator->();
    A23456789012345 *const operator->() const;
};


class A23456789012345
{
  protected:
    typedef void (A23456789012345::*GetFunction)(A23456789012345WOHandle);
    typedef void (A23456789012345::*SetFunction)(A23456789012345WOHandle,
                                                 int);
    struct C23456789
    {
        struct Row
        {
            unsigned id;
            GetFunction get;
            SetFunction set;
        };
        const Row* table;
        unsigned length;
    };
    
  public:

    class B23456789
    {
        friend class A23456789012345;

      public:
        typedef unsigned key_type;  
        class iterator;
        typedef struct value_type
        {
          public:
            unsigned id() const { return attr->id; }
            bool hasGet() const { return attr->get != 0; }
            bool hasSet() const { return attr->set != 0; }

            void get(A23456789012345WOHandle) const;
            void set(A23456789012345WOHandle, int);

          private:
            friend class iterator;
            value_type(A23456789012345Handle mo, const C23456789::Row* attr)
            : mo(mo), attr(attr) {}
            A23456789012345Handle mo;
            const C23456789::Row* attr;
        } value_type;
        typedef const value_type const_reference;  
        typedef value_type reference;
        class iterator
        {
          public:
            iterator() : mo(0), attr(0) {}
            reference operator*() const { return reference(mo, attr); }
            iterator& operator++() { ++attr; return *this; }
            iterator operator++(int)
            { iterator tmp = *this; ++*this; return tmp; }
            iterator& operator--() { --attr; return *this; }
            iterator operator--(int)
            { iterator tmp = *this; --*this; return tmp; }

          protected:
            friend class B23456789;
            iterator(A23456789012345Handle mo, const C23456789::Row* attr)
            : mo(mo), attr(attr) {}

          private:
            A23456789012345Handle mo;
            const C23456789::Row* attr;
        };
        iterator begin() const
        { return iterator(mo, mo->getC23456789().table); }
        A23456789012345Handle mo;
    };
};
