/* Test function-style type casts; ugh, what a language */
class T;

f()
{
	int y(int a);		// func decl
	int z((int) a);		// obj def
	int x(T(a));		// still obj def
	int w(U(a));		// U is not a type, hence init of obj w
}