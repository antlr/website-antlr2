class BADLY;
class BOOL;

template<class T, int *b> class A {
	int i;
	T a;
	f() { a=b; }
};

A<BADLY> afloat;
A<BOOL>  abool;

template<class T, class U> class Wow {
	int i;
	T a;
	U smell(BADLY);
};

Wow<BOOL, BADLY> ick;

/* note: you can't return a 'T' at this point, because the template
 * couldn't add it to the symbol table during guess mode; arghh!!!
 */
template<class T> int f()
{
	int i;
	T a;
	return a;
}
