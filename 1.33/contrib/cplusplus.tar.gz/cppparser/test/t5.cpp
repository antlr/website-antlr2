/* Test user-defined type casting */

class A {
    operator void*() const { ; }
    operator char*() const;
};

A::operator char*() const
{
}

