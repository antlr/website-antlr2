class _IO_FILE;

class ios {
	typedef int openmode;
	enum E { A, B, C };
	void allocbuf() { if (base() == ((void*)0) ) doallocbuf(); }
	void doallocbuf();
	virtual int sync();
	virtual int pbackfail(int c);
	virtual ios* duh(char *p, int len);
};

class streambuf;

class filebuf : public streambuf {
  protected:
    void init();
  public:
    static const int openprot;  
    ~filebuf();
    filebuf();
    filebuf(int fd);
    filebuf(int fd, char* p, int len);
    static filebuf *__new();
    filebuf* attach(int fd);
    filebuf* open(const char *filename, const char *mode);
    filebuf* open(const char *filename, ios::E mode, int prot = 0664);
    virtual int underflow();
};