class SetWordType;
class ScriptParser;
class TokenType;
class ANTLRTokenBase;
class ANTLRChar;
class ASTBase;
class ANTLRParserState;
class OMsymbol;
class OMtype;
class OMaccess;
class Boolean;

void
ScriptParser::external_declaration(ASTBase **_root)
{
	SetWordType *zzMissSet=((void *)0) ; TokenType zzMissTok=(TokenType)0;	ANTLRTokenBase *zzBadTok; ANTLRChar *zzBadText=(ANTLRChar *)"";	int zzErrk=1;	ANTLRChar *zzMissText=(ANTLRChar *)""; ;
	ASTBase **_astp, *_ast = ((void *)0) , *_sibling = ((void *)0) , *_tail = ((void *)0) ;
	AST *_ast11=((void *)0) ,*_ast12=((void *)0) ;
	ANTLRParserState zzst; int zzrv; int _marker; 
	OMsymbol *sym, *psym; OMtype *tspec; 
	Boolean isTypedef; OMaccess acc;   
	tracein("external_declaration");

	_marker = 1;
}