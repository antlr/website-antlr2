/*
 * Main program to test C++ grammar.
 */

#include <stream.h>
#include "tokens.h"
#include "CParser.h"
typedef ANTLRCommonToken ANTLRToken;
#include "DLGLexer.h"
#include "PBlackBox.h"

class MyParser : public CParser {
public:
	MyParser(ANTLRTokenBuffer *input) : CParser(input) {;}
  //	MyParser(ANTLRTokenBuffer *input, TokenType eof) : CParser(input,eof) {;}

	virtual void enterNewLocalScope()
		{ fprintf(stderr, "enterNewLocalScope();\n"); CParser::enterNewLocalScope(); }
	virtual void exitLocalScope()
		{fprintf(stderr, "exitLocalScope();\n"); CParser::exitLocalScope();}

	// Declaration stuff
	virtual void beginDeclaration()
		{fprintf(stderr, "beginDeclaration();\n"); CParser::beginDeclaration();}
	virtual void beginFunctionDefinition()
		{
			fprintf(stderr, "beginFunctionDefinition();\n");
			CParser::beginFunctionDefinition();
		}
	virtual void beginParameterDeclaration()
		{
			fprintf(stderr, "beginParameterDeclaration();\n");
			CParser::beginParameterDeclaration();
		}
	virtual void beginFieldDeclaration()
		{
			fprintf(stderr, "beginFieldDeclaration();\n");
			CParser::beginFieldDeclaration();
		}
	virtual void declarationSpecifier(StorageClass sc,
									  TypeQualifier tq,
									  TypeSpecifier ts)
		{
			fprintf(stderr, "declarationSpecifier();\n");
			CParser::declarationSpecifier(sc,tq,ts);
		}

	// Declarator stuff
	virtual void declaratorPointerTo()
		{
			fprintf(stderr, "declaratorPointerTo();\n");
			CParser::declaratorPointerTo();
		}
	virtual void declaratorID(char *id)
		{
			fprintf(stderr, "declaratorID();\n");
			CParser::declaratorID(id);
		}
	virtual void declaratorArray()
		{
			fprintf(stderr, "declaratorArray();\n");
			CParser::declaratorArray();
		}
	virtual void declaratorParameterList()
		{
			fprintf(stderr, "declaratorParameterList();\n");
			CParser::declaratorParameterList();
		}
	virtual void declaratorEndParameterList()
		{
			fprintf(stderr, "declaratorEndParameterList();\n");
			CParser::declaratorEndParameterList();
		}
};

main(int argc, char *argv[])
{
//    ParserBlackBox<DLGLexer, CParser, ANTLRToken> p(stdin);
    ParserBlackBox<DLGLexer, MyParser, ANTLRToken> p(stdin);
	if ( argc>1 )
	{
		if ( strcmp("-trace", argv[1])==0 ) p.parser()->traceOn();
	}
    p.parser()->translation_unit();
}
