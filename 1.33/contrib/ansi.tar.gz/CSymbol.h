#ifndef CSymbol_h
#define CSymbol_h

#include "DictEntry.h"

class CSymbol : public DictEntry {
public:
	enum ObjectType {
		otINVALID=0, otFunction=1, otVariable, otType,
		otStruct, otUnion, otEnum
	};

protected:
	ObjectType type;

public:
	CSymbol() {;}
	CSymbol(char *k, ObjectType st=otINVALID) : DictEntry(k) { type = st; }
	void setType(ObjectType t)	{ type = t; }
	ObjectType getType()		{ return type; }
};

#endif
