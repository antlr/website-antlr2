#include "Dictionary.h"
#include <strings.h>
#include <stdlib.h>

/* Hashing function described in                   */
/* "Fast Hashing of Variable-Length Text Strings," */
/* by Peter K. Pearson, CACM, June 1990.           */
unsigned char Dictionary::randomNumbers[] =  /* Table from p. 678.*/
{	/* Pseudorandom Permutation of the Integers 0 through 255: */
     1, 14,110, 25, 97,174,132,119,138,170,125,118, 27,233,140, 51,
    87,197,177,107,234,169, 56, 68, 30,  7,173, 73,188, 40, 36, 65,
    49,213,104,190, 57,211,148,223, 48,115, 15,  2, 67,186,210, 28,
    12,181,103, 70, 22, 58, 75, 78,183,167,238,157,124,147,172,144,
   176,161,141, 86, 60, 66,128, 83,156,241, 79, 46,168,198, 41,254,
   178, 85,253,237,250,154,133, 88, 35,206, 95,116,252,192, 54,221,
   102,218,255,240, 82,106,158,201, 61,  3, 89,  9, 42,155,159, 93,
   166, 80, 50, 34,175,195,100, 99, 26,150, 16,145,  4, 33,  8,189,
   121, 64, 77, 72,208,245,130,122,143, 55,105,134, 29,164,185,194,
   193,239,101,242,  5,171,126, 11, 74, 59,137,228,108,191,232,139,
     6, 24, 81, 20,127, 17, 91, 92,251,151,225,207, 21, 98,113,112,
    84,226, 18,214,199,187, 13, 32, 94,220,224,212,247,204,196, 43,
   249,236, 45,244,111,182,153,136,129, 90,217,202, 19,165,231, 71,
   230,142, 96,227, 62,179,246,114,162, 53,160,215,205,180, 47,109,
    44, 38, 31,149,135,  0,216, 52, 63, 23, 37, 69, 39,117,146,184,
   163,200,222,235,248,243,219, 10,152,131,123,229,203, 76,120,209
};

char *Dictionary::strings = NULL;
char *Dictionary::strp = NULL;
unsigned Dictionary::strsize = 0;

Dictionary::Dictionary(int nb, int ns, int nc)
{
	int i;

	bucket = new (DictEntry *[nb]);
	if ( bucket==NULL ) panic("can't alloc buckets");
	nbuckets = nb;
	for (i=0; i<nb; i++) bucket[i]=NULL;
	scope = new (DictEntry *[ns]);
	if ( scope==NULL ) panic("can't alloc scopes");
	endScope = new (DictEntry *[ns]);
	if ( endScope==NULL ) panic("can't alloc scopes");
	nscopes = ns;
	for (i=0; i<ns; i++) scope[i]=NULL;
	currentScope = 0;

	strsize = nc;
	strings = new char[nc];
	strp = strings;
}

Dictionary::~Dictionary()
{
	delete [] bucket;
	delete [] scope;
	delete [] endScope;
	nbuckets = nscopes = 0;
	currentScope = -1;
}

/* Hashing function described in                   */
/* "Fast Hashing of Variable-Length Text Strings," */
/* by Peter K. Pearson, CACM, June 1990.           */
int Dictionary::
hash(char *string)
{
	int hash1  = 0;
    int hash2  = 0;
    int length = 0;

    while( *string != 0 )
    {
	    length++;
	    /* Hash function is XOR of successive characters, randomized by
	     * the hash table.
	     */
	    hash1 ^= randomNumbers[ *string++ ];
	    if ( *string != 0 )
			hash2 ^= randomNumbers[ *string++ ];
	}
//	return ((hash1 << 8) | hash2) ^ length;
	return (hash1 << 8) | hash2;
}

/* Return ptr to 1st entry found in table under key
 * (return NULL if none found).
 */
DictEntry *Dictionary::
lookup(char *key)
{
	DictEntry *q;
	
	int h = hash(key) % nbuckets;
	for (q = bucket[h]; q != NULL; q = q->getNext())
	{
		if ( h==q->getHashCode() && strcmp(key, q->getKey()) == 0 )
		{
			return q;
		}
	}
	return NULL;
}

void Dictionary::
define(char *key, DictEntry *entry)
{
	int h = hash(key) % nbuckets;
	entry->setKey( strdup(key) );	/* make a local copy of key */
	entry->setHashCode( h );
	entry->setNext( bucket[h] );	/* Add to head of singly-linked list */
	bucket[h] = entry;
	if ( endScope[currentScope]==NULL )
		scope[currentScope] = endScope[currentScope] = entry;
	else
	{
		endScope[currentScope]->setScope( entry );
		endScope[currentScope] = entry;
	}
}

void Dictionary::
saveScope()
{
	currentScope++;
	if ( currentScope>=nscopes ) panic("saveScope: overflow");
}

void Dictionary::
restoreScope()
{
	if ( currentScope==0 ) panic("restoreScope: underflow");
	currentScope--;
}

DictEntry *Dictionary::
getCurrentScope()
{
	if ( currentScope<0 || currentScope>nscopes )
		panic("getCurrentScope: no scope");
	return scope[currentScope];
}

/* This unlinks all entries from the Dictionary that are members
 * of the current scope.  The scope is not restored to a previous
 * scope however.
 */
DictEntry *Dictionary::
removeScope()
{
	DictEntry *s, *r;

	for (s=scope[currentScope]; s!=NULL; s=s->getNextInScope())
	{
		remove( s );
	}
	r = scope[currentScope];
	scope[currentScope] = endScope[currentScope] = NULL;
	return r;
}

/* Lookup the object referred to by 'key' and then physically remove
 * it from the Dictionary.  Return the object referred to by the key.
 * If more than one definition is found for 'key', then only the
 * first one is removed.  Return NULL if not found.
 */
DictEntry *Dictionary::
remove(char *key)
{
	DictEntry *q, *prev;

	int h = hash(key) % nbuckets;
	for (prev=NULL, q = bucket[h]; q != NULL; prev = q, q = q->getNext())
	{
		if ( h==q->getHashCode() && strcmp(key, q->getKey()) == 0 )
		{
			if ( prev==NULL ) bucket[h] = q->getNext();
			else prev->setNext( q->getNext() );
			q->setNext(NULL);
			return q;
		}
	}
}

DictEntry *Dictionary::
remove(DictEntry *p)
{
	DictEntry *q, *prev;
	if ( p==NULL ) panic("remove: NULL ptr");
	int h = hash(p->getKey()) % nbuckets;
	for (prev=NULL, q = bucket[h]; q != NULL; prev = q, q = q->getNext())
	{
		if ( p==q )
		{
			if ( prev==NULL ) bucket[h] = p->getNext();
			else prev->setNext( p->getNext() );
			p->setNext(NULL);
			return p;
		}
	}
}

void Dictionary::
dumpSymbol(FILE *f, DictEntry *de)
{
	fprintf(f, "%s\n", de->getKey());
}

void Dictionary::
dumpScope(FILE *f)
{
	DictEntry *s;

	for (s=scope[currentScope]; s!=NULL; s=s->getNextInScope())
	{
		dumpSymbol(f, s);
	}
}

/* Add a string to the string table and return a pointer to it.
 * Bump the pointer into the string table to next avail position.
 */
char *Dictionary::
strdup( char *s )
{
	char *start=strp;
	if ( s==NULL ) panic("strdup: NULL string");

	if ( start+strlen(s)+1 > &(strings[strsize-2]) )
		panic("string table overflow");
	while ( *s != '\0' ) { *strp++ = *s++; }
	*strp++ = '\0';

	return start;
}

void Dictionary::
panic(char *err)
{
	fprintf(stderr, "Dictionary panic: %s\n", err);
	exit(-1);
}
