/*
 * Dictionary.h -- A cool hash table
 *
 * Terence Parr
 * Parr Research Corporation
 * January 1995
 */
#ifndef Dictionary_h
#define Dictionary_h

#include <stdio.h>
#include "DictEntry.h"

class Dictionary {
protected:
	DictEntry **scope, **endScope;
	int nscopes, currentScope;
	DictEntry **bucket;
	int nbuckets;
	static unsigned char randomNumbers[];
	static char *strings;
	static char *strp;
	static unsigned strsize;

protected:
	virtual void dumpSymbol(FILE *, DictEntry *);

public:
	Dictionary(int nb=43, int ns=50, int nc=30000);
	~Dictionary();
	virtual int hash(char *s);
	DictEntry *lookup(char *);
	void define(char *, DictEntry *);
	void saveScope();
	void restoreScope();
	DictEntry *getCurrentScope();
	DictEntry *removeScope();
	DictEntry *remove(char *);
	DictEntry *remove(DictEntry *);

	void dumpScope(FILE *);

	char *strdup(char *);

	virtual void panic(char *);
};

#endif
