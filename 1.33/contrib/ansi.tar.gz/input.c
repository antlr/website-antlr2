# 1 "/circle/s13/parrt/PCCTS/antlr/gen.c" 


































# 1 "/usr/include/stdio.h" 1





extern	struct	_iobuf {
	int	_cnt;
	unsigned char *_ptr;
	unsigned char *_base;
	int	_bufsiz;
	short	_flag;
	char	_file;		
} _iob[];



















# 36 "/usr/include/stdio.h" 

















extern struct _iobuf	*fopen();
extern struct _iobuf	*fdopen();
extern struct _iobuf	*freopen();
extern struct _iobuf	*popen();
extern struct _iobuf	*tmpfile();
extern long	ftell();
extern char	*fgets();
extern char	*gets();
extern char	*sprintf();
extern char	*ctermid();
extern char	*cuserid();
extern char	*tempnam();
extern char	*tmpnam();






# 36 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2
# 1 "/usr/include/ctype.h" 1












extern	char	_ctype_[];














# 37 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2
# 1 "../../support/set/set.h" 1


















# 1 "../../h/config.h" 1










































# 45 "../../h/config.h" 

# 50 "../../h/config.h" 





















# 74 "../../h/config.h" 

# 78 "../../h/config.h" 









# 89 "../../h/config.h" 







# 100 "../../h/config.h" 

# 105 "../../h/config.h" 







# 129 "../../h/config.h" 
# 132 "../../h/config.h" 
# 137 "../../h/config.h" 


# 141 "../../h/config.h" 




# 147 "../../h/config.h" 

static

# 155 "../../h/config.h" 

void special_inits()
{
}


# 163 "../../h/config.h" 

static

# 171 "../../h/config.h" 

void

special_fopen_actions(char *s)
# 178 "../../h/config.h" 

{
}














# 198 "../../h/config.h" 





# 208 "../../h/config.h" 



# 20 "../../support/set/set.h" 2

# 31 "../../support/set/set.h" 







typedef struct _set {
			unsigned int n;		
			unsigned *setword;
		} set;




















# 87 "../../support/set/set.h" 

extern void set_size();
extern unsigned int set_deg();
extern set set_or();
extern set set_and();
extern set set_dif();
extern set set_of();
extern void set_ext();
extern set set_not();
extern int set_equ();
extern int set_sub();
extern unsigned set_int();
extern int set_el();
extern int set_nil();
extern char * set_str();
extern set set_val();
extern void set_orel();
extern void set_orin();
extern void set_rm();
extern void set_clr();
extern set set_dup();
extern void set_PDQ();
extern unsigned *set_pdq();
extern void _set_pdq();
extern unsigned int set_hash();


extern set empty;
# 38 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2
# 1 "/circle/s13/parrt/PCCTS/antlr/syn.h" 1























































typedef int NodeType;








typedef struct _tree {
			struct _tree *down, *right;
			int token;
			union {
				int rk;	
				struct _tree *tref;	
				set sref;			
			} v;
# 75 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

		} Tree;













typedef struct _Predicate {
	struct _Predicate *down, *right;	
	char *expr;
	Tree *tcontext;	
	set scontext[2];
					


	set completion;	
} Predicate;

typedef struct _ExceptionHandler {
			char *signalname;
			char *action;
		} ExceptionHandler;

typedef struct _ExceptionGroup {
			struct _ListNode *handlers; 
			char *label;		


			char *altID;		
		} ExceptionGroup ;






				





















# 146 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

typedef struct _node {
			NodeType ntype;
		} Node;


# 155 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

typedef struct _anode {
			NodeType ntype;

			Node *next;
			char *action;
			int file;			
			int line;			
			int is_predicate;	
			int done;			
			int init_action;	
			char *pred_fail;	
# 169 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

		} ActionNode;


# 176 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

typedef struct _toknode {
			NodeType ntype;

			Node *next;
			char *rname;		
			int file;			
			int line;			
			int token;
			int astnode;		
			unsigned char label;
			unsigned char remapped;
								

			unsigned char upper_range;
								


			unsigned char wild_card;
								


			unsigned int elnum; 
			struct _junct *altstart;	
			struct _TCnode *tclass;		
			set tset;			
			char *el_label;		
			unsigned char complement;	
			ExceptionGroup *ex_group;	
            unsigned char use_def_MT_handler;
# 208 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

		} TokNode;


# 215 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

typedef struct _rrnode {
			NodeType ntype;

			Node *next;
			char *rname;		
			int file;			

			int line;			
			char *text;			
			char *parms;		

			char *assign;		

			int linked;			
			int astnode;		
			unsigned int elnum; 
			struct _junct *altstart;
			char *el_label;		
			ExceptionGroup *ex_group;	
# 237 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

		} RuleRefNode;


# 244 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

typedef struct _junct {
			NodeType ntype;

			char ignore;		

			char visited;		

			char pvisited;		

			char fvisited;		

			char *lock;			
			char *pred_lock;	
			int altnum;			

			int jtype;			

# 265 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

			struct _junct *end;	


			Node *p1, *p2;
			char *rname;		
			int file;			

			int line;			
			int halt;			
			char *pdecl;		

			char *parm;			

			int predparm;		


			char *ret;			
			char *erraction;	
			int blockid;		
			char *exception_label;	
			set *fset;			
			Tree *ftree;		
			Predicate *predicate;
			char guess;			
			char approx;		
			set tokrefs;		
			set rulerefs;		
			struct _ListNode *exceptions; 
			struct _ListNode *el_labels;  
# 297 "/circle/s13/parrt/PCCTS/antlr/syn.h" 

		} Junction;


typedef struct { Node *left, *right; } Graph;

# 39 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2
# 1 "/circle/s13/parrt/PCCTS/antlr/hash.h" 1

































				








typedef struct _entry {		
			char *str;
			struct _entry *next;
		} Entry;






# 60 "/circle/s13/parrt/PCCTS/antlr/hash.h" 

Entry *hash_get(), **newHashTable(), *hash_add();

# 40 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2
# 1 "/circle/s13/parrt/PCCTS/antlr/generic.h" 1












































					








				





					

typedef struct _ListNode {
			void *elem;			
			struct _ListNode *next;
		} ListNode;




typedef struct _c {
			int croot;			
			set cyclicDep;		
			unsigned deg;		
		} Cycle;

typedef struct _e {
			int tok;			
			ListNode *elist;	
			set eset;
			int setdeg;			
			int lexclass;		
		} ECnode;

typedef struct _TCnode {
			int tok;			
			ListNode *tlist;	
			set tset;
			int lexclass;		
			unsigned char dumped; 
			unsigned setnum;	
		} TCnode;

typedef struct _ft {
			char *token;		
			int tnum;			
		} ForcedToken;







				

typedef struct _t {				
			char *str;
			struct _t *next;
			int token;			
			unsigned char classname;	
			TCnode *tclass;		
			char *action;
		} TermEntry;

typedef struct _r {				
			char *str;
			struct _t *next;
			int rulenum;		
			unsigned char noAST;
			char *egroup;		
			ListNode *el_labels;
            unsigned char has_rule_exception;
		} RuleEntry;

typedef struct _f {				
			char *str;			
			struct _f *next;
			set fset;			
			set rk;				
			int incomplete;		
		} CacheEntry;

typedef struct _LabelEntry {	
			char *str;
			struct _f *next;
			Node *elem;			
			ExceptionGroup *ex_group;
								
		} LabelEntry;

typedef struct _SignalEntry {
			char *str;
			struct _f *next;
			int signum;			
		} SignalEntry;








typedef struct _UserAction {
			char *action;
			int file, line;
		} UserAction;


					


typedef struct _lc {
			char *classnum, **exprs;
			Entry **htable;
		} LClass;

typedef struct _exprOrder {
			char *expr;
			int lclass;
		} Expr;


typedef Graph Attrib;

						

# 180 "/circle/s13/parrt/PCCTS/antlr/generic.h" 

# 183 "/circle/s13/parrt/PCCTS/antlr/generic.h" 














           




























# 1 "/circle/s13/parrt/PCCTS/antlr/proto.h" 1

































                           

extern int tp;
extern Junction *SynDiag;
extern char Version[];
extern char VersionDef[];
# 42 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern void (*fpPrint[])();

# 47 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern struct _set (*fpReach[])();

# 52 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern struct _tree *(*fpTraverse[])();

# 57 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern void (**fpTrans)();

# 62 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern void (**fpJTrans)();

# 67 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern void (*C_Trans[])();

# 72 "/circle/s13/parrt/PCCTS/antlr/proto.h" 

extern void (*C_JTrans[])();

extern int BlkLevel;
extern int CurFile;
extern char *CurRule;
extern Junction *CurRuleBlk;
extern RuleEntry *CurRuleNode;
extern ListNode *CurElementLabels;
extern char *FileStr[];
extern int NumFiles;
extern int EpToken;
extern int WildCardToken;
extern Entry	**Tname,
				**Texpr,
				**Rname,
				**Fcache,
				**Tcache,
				**Elabel,
				**Sname;
extern ListNode *ExprOrder;
extern ListNode **Cycles;
extern int TokenNum;
extern int LastTokenCounted;
extern ListNode *BeforeActions, *AfterActions, *LexActions;
extern ListNode *eclasses, *tclasses;
extern char	*HdrAction;
extern struct _iobuf	*ErrFile;
extern char *RemapFileName;
extern char *ErrFileName;
extern char *DlgFileName;
extern char *DefFileName;
extern char *ModeFileName;
extern int NumRules;
extern Junction **RulePtr;
extern int LL_k;
extern int CLL_k;
extern char *decodeJType[];
extern int PrintOut;
extern int PrintAnnotate;
extern int CodeGen;
extern int LexGen;
extern int esetnum;
extern int setnum;
extern int wordnum;
extern int GenAST;
extern int GenANSI;
extern int **FoStack;
extern int **FoTOS;
extern int GenExprSets;
extern struct _iobuf *DefFile;
extern int CannotContinue;
extern int GenCR;
extern int GenLineInfo;
extern int action_file, action_line;
extern int TraceGen;
extern int CurAmbigAlt1, CurAmbigAlt2, CurAmbigline, CurAmbigfile;
extern char *CurAmbigbtype;
extern int elevel;
extern int GenEClasseForRules;
extern struct _iobuf *input, *output;
extern char **TokenStr, **ExprStr;
extern int CurrentLexClass, NumLexClasses;
extern LClass lclass[];
extern char LexStartSymbol[];
extern char	*CurRetDef;
extern char	*CurParmDef;
extern int OutputLL_k;
extern int TreeResourceLimit;
extern int DemandLookahead;
extern char *RulePrefix;
extern int GenStdPccts;
extern char *stdpccts;
extern int ParseWithPredicates;
extern int ConstrainSearch;
extern int FoundGuessBlk;
extern int FoundException;
extern int WarningLevel;
extern int pLevel;
extern int pAlt1;
extern int pAlt2;
extern int AImode;
extern int HoistPredicateContext;
extern int GenCC;
extern char *ParserName;
extern char *StandardSymbols[];
extern char *ASTSymbols[];
extern set reserved_positions;
extern set all_tokens;
extern set imag_tokens;
extern set tokclasses;
extern ListNode *ForcedTokens;
extern int *TokenInd;
extern struct _iobuf *Parser_h, *Parser_c;
extern char CurrentClassName[];
extern int no_classes_found;
extern char Parser_h_Name[];
extern char Parser_c_Name[];
extern ListNode *class_before_actions, *class_after_actions;
extern char *UserTokenDefsFile;
extern int UserDefdTokens;
extern ListNode *MetaTokenNodes;
extern char *OutputDirectory;
extern int DontCopyTokens;
extern set AST_nodes_refd_in_actions;
extern ListNode *CurExGroups;
extern int CurBlockID;
extern int CurAltNum;
extern Junction *CurAltStart;
extern ExceptionGroup *DefaultExGroup;
extern int NumSignals;



extern void istackreset(void);
extern int istacksize(void);
extern void pushint(int);
extern int popint( void );
extern int istackempty( void );
extern int topint( void );
extern void NewSetWd( void );
extern void DumpSetWd( void );
extern void DumpSetWdForC( void );
extern void DumpSetWdForCC( void );
extern void NewSet( void );
extern void FillSet( set );
extern void ComputeErrorSets( void );
extern void ComputeTokSets( void );
extern void SubstErrorClass( set * );
extern int DefErrSet( set *, int, char * );
extern int DefErrSetForC( set *, int, char * );
extern int DefErrSetForCC( set *, int, char * );
extern void GenErrHdr( void );
extern void dumpExpr( struct _iobuf *, char * );
extern void addParm( Node *, char * );
extern Graph buildAction( char *, int, int, int );
extern Graph buildToken( char * );
extern Graph buildWildCard( char * );
extern Graph buildRuleRef( char * );
extern Graph Or( Graph, Graph );
extern Graph Cat( Graph, Graph );
extern Graph makeOpt( Graph, int );
extern Graph makeBlk( Graph, int );
extern Graph makeLoop( Graph, int );
extern Graph makePlus( Graph, int );
extern Graph emptyAlt( void );
extern TokNode * newTokNode( void );
extern RuleRefNode * newRNode( void );
extern Junction * newJunction( void );
extern ActionNode * newActionNode( void );
extern char * makelocks( void );
extern void preorder( Tree * );
extern Tree * tnode( int );
extern void _Tfree( Tree * );
extern Tree * tdup( Tree * );
extern Tree * tappend( Tree *, Tree * );
extern void Tfree( Tree * );
extern Tree * tlink( Tree *, Tree *, int );
extern Tree * tshrink( Tree * );
extern Tree * tflatten( Tree * );
extern Tree * tJunc( Junction *, int, set * );
extern Tree * tRuleRef( RuleRefNode *, int, set * );
extern Tree * tToken( TokNode *, int, set * );
extern Tree * tAction( ActionNode *, int, set * );
extern int tmember( Tree *, Tree * );
extern Tree * tleft_factor( Tree * );
extern Tree * trm_perm( Tree *, Tree * );
extern void tcvt( set *, Tree * );
extern Tree * permute( int );
extern Tree * VerifyAmbig( Junction *, Junction *, unsigned **, set *, Tree **, Tree **, int * );
extern set rJunc( Junction *, int, set * );
extern set rRuleRef( RuleRefNode *, int, set * );
extern set rToken( TokNode *, int, set * );
extern set rAction( ActionNode *, int, set * );
extern void HandleAmbiguity( Junction *, Junction *, Junction *, int );
extern set First( Junction *, int, int, int * );
extern void freeBlkFsets( Junction * );
extern void genAction( ActionNode * );
extern void genRuleRef( RuleRefNode * );
extern void genToken( TokNode * );
extern void genOptBlk( Junction * );
extern void genLoopBlk( Junction *, Junction *, Junction *, int );
extern void genLoopBegin( Junction * );
extern void genPlusBlk( Junction * );
extern void genSubBlk( Junction * );
extern void genRule( Junction * );
extern void genJunction( Junction * );
extern void genEndBlk( Junction * );
extern void genEndRule( Junction * );
extern void genHdr( int );
extern void genHdr1( int );
extern void dumpAction( char *, struct _iobuf *, int, int, int, int );
extern Entry ** newHashTable( void );
extern Entry * hash_add( Entry **, char *, Entry * );
extern Entry * hash_get( Entry **, char * );
extern void hashStat( Entry ** );
extern char * mystrdup( char * );
extern void genLexDescr( void );
extern void dumpLexClasses( struct _iobuf * );
extern void genDefFile( void );
extern void DumpListOfParmNames( char *, struct _iobuf * );
extern int DumpNextNameInDef( char **, struct _iobuf * );
extern void DumpOldStyleParms( char *, struct _iobuf * );
extern void DumpType( char *, struct _iobuf * );
extern int strmember( char *, char * );
extern int HasComma( char * );
extern void DumpRetValStruct( struct _iobuf *, char *, int );
extern char * StripQuotes( char * );
extern int main( int, char *[] );
extern void readDescr( void );
extern struct _iobuf * NextFile( void );
extern char * outname( char * );
extern void fatalFL( char *, char *, int );
extern void fatal_intern( char *, char *, int );
extern void cleanUp( void );
extern char * eMsg3( char *, char *, char *, char * );
extern char * eMsgd( char *, int );
extern void s_fprT( struct _iobuf *, set );
extern char * TerminalString( int );
extern void lexclass( char * );
extern void lexmode( int );
extern int LexClassIndex( char * );
extern int hasAction( char * );
extern void setHasAction( char *, char * );
extern int addTname( char * );
extern int addTexpr( char * );
extern int Tnum( char * );
extern void Tklink( char *, char * );
extern Entry * newEntry( char *, int );
extern void list_add( ListNode **, void * );
extern void list_apply( ListNode *, void (*)(void *) );
extern char * Fkey( char *, int, int );
extern void FoPush( char *, int );
extern void FoPop( int );
extern void RegisterCycle( char *, int );
extern void ResolveFoCycles( int );
extern void pJunc( Junction * );
extern void pRuleRef( RuleRefNode * );
extern void pToken( TokNode * );
extern void pAction( ActionNode * );
extern void FoLink( Node * );
extern void addFoLink( Node *, char *, Junction * );
extern void GenCrossRef( Junction * );
extern void defErr( char *, long, long, long, long, long, long );
extern void genStdPCCTSIncludeFile(struct _iobuf *);
extern Predicate *find_predicates(Node *);
extern void GenRulePrototypes(struct _iobuf *, Junction *);
extern Junction *first_item_is_guess_block(Junction *);
extern Junction *analysis_point(Junction *);
extern Tree *make_tree_from_sets(set *, set *);
extern Tree *tdup_chain(Tree *);
extern Tree *tdif(Tree *, Predicate *, set *, set *);
extern set covered_set(Predicate *);
extern void AmbiguityDialog(Junction *, int, Junction *, Junction *, int *, int *);
extern void dumpAmbigMsg(set *, struct _iobuf *, int);
extern void GenRuleFuncRedefs(struct _iobuf *, Junction *);
extern void GenPredefinedSymbolRedefs(struct _iobuf *);
extern void GenASTSymbolRedefs(struct _iobuf *);
extern void GenRemapFile(void);
extern void GenSetRedefs(struct _iobuf *);
extern ForcedToken *newForcedToken(char *, int);
extern void RemapForcedTokens(void);
extern char *TokenOrExpr(int);
extern void setUpperRange(TokNode *, char *);
extern void GenParser_c_Hdr(void);
extern void GenParser_h_Hdr(void);
extern void GenRuleMemberDeclarationsForCC(struct _iobuf *, Junction *);
extern int addForcedTname( char *, int );
extern char *OutMetaName(char *);
extern void warnNoFL(char *err);
extern void warnFL(char *err,char *f,int l);
extern void warn(char *err);
extern void warnNoCR( char *err );
extern void errNoFL(char *err);
extern void errFL(char *err,char *f,int l);
extern void err(char *err);
extern void errNoCR( char *err );
extern Tree *tmake(Tree *root, ...);
extern void genPredTree( Predicate *p, Junction *j );
extern UserAction *newUserAction(char *);
extern char *gate_symbol(char *name);
extern char *makeAltID(int blockid, int altnum);
extern void DumpRemainingTokSets();
extern void DumpANSIFunctionArgDef(struct _iobuf *f, Junction *q);
# 527 "/circle/s13/parrt/PCCTS/antlr/proto.h" 



# 1 "/usr/include/stdlib.h" 1









# 1 "/usr/include/sys/stdtypes.h" 1













typedef	int		sigset_t;	

typedef	unsigned int	speed_t;	
typedef	unsigned long	tcflag_t;	
typedef	unsigned char	cc_t;		
typedef	int		pid_t;		

typedef	unsigned short	mode_t;		
typedef	short		nlink_t;	

typedef	long		clock_t;	
typedef	long		time_t;		

typedef	int		size_t;		
typedef int		ptrdiff_t;	

typedef	unsigned short	wchar_t;	


# 11 "/usr/include/stdlib.h" 2

extern unsigned int _mb_cur_max;





extern int	abort();
extern int	abs();
extern double	atof();
extern int	atoi();
extern long int	atol();
extern char *	bsearch(
);
extern char *	calloc();
extern int	exit();
extern int	free();
extern char *	getenv();
extern char *	malloc();
extern int	qsort(
);
extern int	rand();
extern char *	realloc();
extern int	srand();

extern int    mbtowc();
extern int    wctomb();
extern size_t mbstowcs();
extern size_t wcstombs();


# 531 "/circle/s13/parrt/PCCTS/antlr/proto.h" 2

# 227 "/circle/s13/parrt/PCCTS/antlr/generic.h" 2
# 1 "../../h/config.h" 1
# 129 "../../h/config.h" 
# 132 "../../h/config.h" 
# 210 "../../h/config.h" 

# 228 "/circle/s13/parrt/PCCTS/antlr/generic.h" 2
# 1 "/usr/include/string.h" 1





# 1 "/usr/include/sys/stdtypes.h" 1










# 32 "/usr/include/sys/stdtypes.h" 

# 7 "/usr/include/string.h" 2

# 10 "/usr/include/string.h" 


extern char *	strcat();
extern char *	strchr();
extern int	strcmp();
extern char *	strcpy();
extern size_t	strcspn();

extern char *	strdup();

extern size_t	strlen();
extern char *	strncat();
extern int	strncmp();
extern char *	strncpy();
extern char *	strpbrk();
extern char *	strrchr();
extern size_t	strspn();
extern char *	strstr();
extern char *	strtok();


# 229 "/circle/s13/parrt/PCCTS/antlr/generic.h" 2
# 41 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2
# 1 "../../h/dlgdef.h" 1


































# 1 "../../h/config.h" 1
# 129 "../../h/config.h" 
# 132 "../../h/config.h" 
# 210 "../../h/config.h" 

# 36 "../../h/dlgdef.h" 2


# 40 "../../h/dlgdef.h" 





struct zzdlg_state {
	struct _iobuf *stream;
	int (*func_ptr)();
	char *str;
	int auto_num;
	int add_erase;
	int lookc;
	int char_full;
	int begcol, endcol;
	int line;
	char *lextext, *begexpr, *endexpr;
	int bufsize;
	int bufovf;
	char *nextpos;
	int	class_num;
};

extern char	*zzlextext;  	
extern char	*zzbegexpr;	
extern char	*zzendexpr;	
extern int	zzbufsize;	
extern int	zzbegcol;	
extern int	zzendcol;	
extern int	zzline;		
extern int	zzreal_line;		
extern int	zzchar;		
extern int	zzbufovf;	

extern void	(*zzerr)(const char *);
# 76 "../../h/dlgdef.h" 


# 80 "../../h/dlgdef.h" 



extern void	zzadvance(void);
extern void	zzskip(void);	
extern void	zzmore(void);	
extern void	zzmode(int k);	
extern void	zzrdstream(struct _iobuf *);
extern void	zzclose_stream(void);
extern void	zzrdfunc(int (*)());
extern void zzrdstr( char * );
extern void	zzgettok(void);	
extern void	zzreplchar(char c);

extern void	zzreplstr(char *s);

extern void zzsave_dlg_state(struct zzdlg_state *);
extern void zzrestore_dlg_state(struct zzdlg_state *);
extern int zzerr_in(void);
extern void	zzerrstd(const char *);
extern void zzerraction();

# 122 "../../h/dlgdef.h" 



# 42 "/circle/s13/parrt/PCCTS/antlr/gen.c" 2


static int on1line=0;
static set tokensRefdInBlock;


					



# 61 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

void (*C_Trans[4+1])() = {
	0,
	0,					

	genRuleRef,
	genToken,
	genAction
};





# 88 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

void (*C_JTrans[9+1])() = {
	0,
	genSubBlk,
	genOptBlk,
	genLoopBlk,
	genEndBlk,
	genRule,
	genJunction,
	genEndRule,
	genPlusBlk,
	genLoopBegin
};




static int tabs = 0;

static void

tab( void )
# 112 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{ int i; for (i=0; i<tabs; i++) fputc('\t', output); }


static char *tokenFollowSet(TokNode *);
static ActionNode *findImmedAction( Node * );
static void dumpRetValAssign(char *, char *);
static void dumpAfterActions(struct _iobuf *output);
static set ComputeErrorSet(Junction *, int);
static void makeErrorClause(Junction *, set, int);
static void DumpFuncHeader( Junction *, RuleEntry * );
static int has_guess_block_as_first_item(Junction *);
static int genExprSets(set *, int);
static void genExprTree( Tree *t, int k );
# 137 "/circle/s13/parrt/PCCTS/antlr/gen.c" 




















static void

warn_about_using_gk_option(void)
# 162 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	static int warned_already=0;

	if ( !DemandLookahead || warned_already ) return;
	warned_already = 1;
	warnNoFL("-gk option could cause trouble for <<...>>? predicates");
}

void

freeBlkFsets( Junction *q )
# 177 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int i;
	Junction *alt;
	{if ( !(q!=0) ) fatal_intern( "freeBlkFsets: invalid node", "/circle/s13/parrt/PCCTS/antlr/gen.c", 181);};

	for (alt=q; alt != 0; alt= (Junction *) alt->p2 )
	{
		for (i=1; i<=CLL_k; i++) {if ( (alt->fset[i]).setword != 0 ) free((char *)((alt->fset[i]).setword)); (alt->fset[i]) = empty;};
	}
}





static void

genTokenPointers( Junction *q )
# 199 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	





	int first=1, t;
	set a;
	tokensRefdInBlock = q->tokrefs;

	if ( set_deg(q->tokrefs) == 0 ) return;
	a = set_dup(q->tokrefs);
	{tab(); fprintf(output, "ANTLRToken ");};
	for (; !set_nil(a); set_rm(t, a))
	{
		t = set_int(a);
		if ( first ) first = 0;
		else {fprintf(output, ",");};
		if ( !DontCopyTokens ) {fprintf(output, "_tv%d%d,", BlkLevel, t);};
		{fprintf(output, "*_t%d%d", BlkLevel, t);};
		if ( !DontCopyTokens ) {{fprintf(output, "= &_tv%d%d", BlkLevel, t);};}
		else {fprintf(output, "=NULL");};
	}
	{fprintf(output, ";\n");};
	{if ( (a).setword != 0 ) free((char *)((a).setword)); (a) = empty;};
}

static int

hasDefaultException(ExceptionGroup *eg)
# 234 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
    ListNode *q;

    for (q = eg->handlers->next; q!=0; q=q->next)
    {
        ExceptionHandler *eh = (ExceptionHandler *)q->elem;
        if ( strcmp("default", eh->signalname)==0 ) {
            return 1;
        }
    }
    return 0;
}

static void

dumpException(ExceptionGroup *eg, int no_default_case)
# 255 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	{tab(); fprintf(output, "switch ( _signal ) {\n", eg->label==0?"":eg->label);};
	{	
		ListNode *q;
		for (q = eg->handlers->next; q!=0; q=q->next)
		{
			ExceptionHandler *eh = (ExceptionHandler *)q->elem;
			if ( strcmp("default", eh->signalname)==0 ) {
				{tab(); fprintf(output, "default :\n");};
				tabs++;
				dumpAction(eh->action, output, tabs, -1, 1, 1);
                {tab(); fprintf(output, "_signal = NoSignal;\n");};
				tabs--;
				{tab(); fprintf(output, "}\n");};
				return;
			}
			{tab(); fprintf(output, "case %s :\n", eh->signalname);};
			tabs++;
			if ( eh->action != 0 )
			{
				dumpAction(eh->action, output, tabs, -1, 1, 1);
                {tab(); fprintf(output, "_signal = NoSignal;\n");};
				{tab(); fprintf(output, "break;\n");};
			}
			tabs--;
		}
	}
	if ( no_default_case ) return;

	{tab(); fprintf(output, "default :\n");};
	tabs++;

	{tab(); fprintf(output, "goto _handler;\n");};
	tabs--;
	{tab(); fprintf(output, "}\n");};
}

static void

dumpExceptions(ListNode *list)
# 299 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	ListNode *p;

	for (p = list->next; p!=0; p=p->next)
	{
		ExceptionGroup *eg = (ExceptionGroup *) p->elem;
		
# 308 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{fprintf(output, "%s%s_handler:\n", 			  eg->label==0?"":eg->label, 			  eg->altID==0?"":eg->altID);};
		if ( eg->altID!=0 ) dumpException(eg, 0);
		else {
			
			dumpException(eg, 1);
			if ( !hasDefaultException(eg) )
            {
                {tab(); fprintf(output, "default :\n");};
                tabs++;
                {tab(); fprintf(output, "zzdflthandlers(_signal,_retsignal);\n");};
                tabs--;
                {tab(); fprintf(output, "}\n");};
            }
		}
	}
}




void

genElementLabels(ListNode *list)
# 334 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int first=1;
	ListNode *p;

	if ( GenCC ) {{tab(); fprintf(output, "ANTLRToken");};}
	else {{tab(); fprintf(output, "Attrib");};}
	for (p = list->next; p!=0; p=p->next)
	{
		char *ep = (char *)p->elem;
		if ( first ) first = 0;
		else {fprintf(output, ",");};
		if ( GenCC ) {{fprintf(output, " *%s=NULL",ep);};}
		else {{fprintf(output, " %s",ep);};}
	}
	{fprintf(output, ";\n");};

	if ( !GenAST ) return;

	first = 1;
	{tab(); fprintf(output, "AST");};
	for (p = list->next; p!=0; p=p->next)
	{
		char *ep = (char *)p->elem;
		if ( first ) first = 0;
		else {fprintf(output, ",");};
		{fprintf(output, " *%s_ast=NULL",ep);};
	}
	{fprintf(output, ";\n");};
}





static void

genASTPointers( Junction *q )
# 375 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int first=1, t;
	set a;

	a = set_or(q->tokrefs, q->rulerefs);
	if ( set_deg(a) > 0 )
	{
		{tab(); fprintf(output, "AST ");};
		for (; !set_nil(a); set_rm(t, a))
		{
			t = set_int(a);
			if ( first ) first = 0;
			else {fprintf(output, ",");};
			{fprintf(output, "*_ast%d%d=NULL", BlkLevel, t);};
		}
		{if ( (a).setword != 0 ) free((char *)((a).setword)); (a) = empty;};
	}
	{fprintf(output, ";\n");};
}

static void

BLOCK_Head( void )
# 401 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	{tab(); fprintf(output, "{\n");};
	tabs++;
	if ( !GenCC ) {tab(); fprintf(output, "zzBLOCK(zztasp%d);\n", BlkLevel);};
}

static void

BLOCK_Tail( void )
# 413 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	if ( !GenCC ) {tab(); fprintf(output, "zzEXIT(zztasp%d);\n", BlkLevel);};
	if ( !GenCC ) {tab(); fprintf(output, "}\n");};
	tabs--;
	{tab(); fprintf(output, "}\n");};
}

static void

BLOCK_Preamble( Junction *q )
# 427 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	ActionNode *a;
	Junction *begin;

	BLOCK_Head();
	if ( GenCC ) genTokenPointers(q);
	if ( GenCC&&GenAST ) genASTPointers(q);
	if ( q->jtype == 8 ) {tab(); fprintf(output, "int zzcnt=1;\n");};
	if ( q->parm != 0 && !q->predparm ) {tab(); fprintf(output, "zzaPush(%s);\n", q->parm);}
	else if ( !GenCC ) {tab(); fprintf(output, "zzMake0;\n");};
	if ( !GenCC ) {tab(); fprintf(output, "{\n");};
	if ( q->jtype == 9 ) begin = (Junction *) ((Junction *)q->p1);
	else begin = q;
	if ( has_guess_block_as_first_item(begin) )
	{
		{tab(); fprintf(output, "zzGUESS_BLOCK\n");};
	}
	if ( q->jtype == 9 )
		a = findImmedAction( ((Junction *)q->p1)->p1 );	
	else
		a = findImmedAction( q->p1 );
	if ( a!=0 && !a->is_predicate ) {
		dumpAction(a->action, output, tabs, a->file, a->line, 1);
		a->done = 1;	
	}
}







































void

genPredTree( Predicate *p, Junction *j )
# 500 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int context_was_present = 0;

	{fprintf(output, "(");};
	for (; p!=0; p=p->right)
	{
		if ( HoistPredicateContext )
		{
			context_was_present = 0;
			if ( LL_k>1 && p->tcontext!=0 )
			{
				context_was_present = 1;
				{fprintf(output, "((");};
				genExprTree(p->tcontext, 1);
				{fprintf(output, ") ? ");};
			}
			else if ( LL_k==1 && set_deg(p->scontext[1])>0 )
			{
				context_was_present = 1;
				{fprintf(output, "((");};
				genExprSets(&(p->scontext[0]), CLL_k);
				{fprintf(output, ") ? ");};
			}
		}

		if ( FoundException ) {{fprintf(output, "(_sva=(");};}
		else {{fprintf(output, "(");};}
		dumpAction(p->expr, output, 0, -1 , j->line, 0);
		if ( FoundException ) {{fprintf(output, "))");};}
		else {{fprintf(output, ")");};}

		if ( HoistPredicateContext && context_was_present ) {fprintf(output, " : 1)");};

		if ( p->down!=0 )
		{
			{fprintf(output, "&&");};
			genPredTree(p->down, j);
		}

		if ( p->right!=0 ) {fprintf(output, "||");};
	}
	{fprintf(output, ")");};
}

static void

genExprTree( Tree *t, int k )
# 552 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	{if ( !(t!=0) ) fatal_intern( "genExprTree: NULL tree", "/circle/s13/parrt/PCCTS/antlr/gen.c", 554);};
	
	if ( t->token == TokenNum+1 )
	{
		{fprintf(output, "(");}; genExprTree(t->down, k); {fprintf(output, ")");};
		if ( t->right!=0 )
		{
			{fprintf(output, "||");};
			on1line++;
			if ( on1line > 4 ) { on1line=0; {fprintf(output, "\n");}; }
			{fprintf(output, "(");}; genExprTree(t->right, k); {fprintf(output, ")");};
		}
		return;
	}
	if ( t->down!=0 ) {fprintf(output, "(");};
	{fprintf(output, "LA(%d)==",k);};
	if ( ((TokenInd!=0)?TokenStr[TokenInd[t->token]]:TokenStr[t->token]) == 0 ) {fprintf(output, "%d", t->token);}
	else {fprintf(output, "%s", ((TokenInd!=0)?TokenStr[TokenInd[t->token]]:TokenStr[t->token]));};
	if ( t->down!=0 )
	{
		{fprintf(output, "&&");};
		on1line++;
		if ( on1line > 4 ) { on1line=0; {fprintf(output, "\n");}; }
		{fprintf(output, "(");}; genExprTree(t->down, k+1); {fprintf(output, ")");};
	}
	if ( t->down!=0 ) {fprintf(output, ")");};
	if ( t->right!=0 )
	{
		{fprintf(output, "||");};
		on1line++;
		if ( on1line > 4 ) { on1line=0; {fprintf(output, "\n");}; }
		{fprintf(output, "(");}; genExprTree(t->right, k); {fprintf(output, ")");};
	}
}




















static int

genExpr( Junction *j )
# 614 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int max_k;

	


	{
		int limit;
		if ( j->ftree!=0 ) limit = LL_k;
		else limit = CLL_k;
		max_k = genExprSets(j->fset, limit);
	}

	



	if ( j->ftree != 0 )
	{
		{fprintf(output, " && !(");}; genExprTree(j->ftree, 1); {fprintf(output, ")");};
	}

	if ( ParseWithPredicates && j->predicate!=0 )
	{
		Predicate *p = j->predicate;
		warn_about_using_gk_option();
		{fprintf(output, "&&");};
		genPredTree(p, j);
	}

	return max_k;
}

static int

genExprSets( set *fset, int limit )
# 655 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int k = 1;
	int max_k = 0;
	unsigned *e, *g, firstTime=1;

	if ( GenExprSets )
	{
		while ( !set_nil(fset[k]) && k<=limit )
		{
			if ( set_deg(fset[k])==1 )	
			{
				int e;
				{fprintf(output, "(LA(%d)==",k);};
				e = set_int(fset[k]);
				if ( ((TokenInd!=0)?TokenStr[TokenInd[e]]:TokenStr[e]) == 0 ) {fprintf(output, "%d)", e);}
				else {fprintf(output, "%s)", ((TokenInd!=0)?TokenStr[TokenInd[e]]:TokenStr[e]));};
			}
			else
			{
				NewSet();
				FillSet( fset[k] );
				{fprintf(output, "(setwd%d[LA(%d)]&0x%x)", wordnum, k, 1<<setnum);};
			}
			if ( k>max_k ) max_k = k;
			if ( k == CLL_k ) break;
			k++;
			if ( !set_nil(fset[k]) && k<=limit ) {fprintf(output, " && ");};
			on1line++;
			if ( on1line > 4 ) { on1line=0; {fprintf(output, "\n");}; }
		}
		return max_k;
	}

	while ( !set_nil(fset[k]) && k<=limit )
	{
		if ( (e=g=set_pdq(fset[k])) == 0 ) fatal_intern("genExpr: cannot allocate IF expr pdq set", "/circle/s13/parrt/PCCTS/antlr/gen.c", 691);
		for (; *e!=(~((unsigned) 0)); e++)
		{
			if ( !firstTime ) {fprintf(output, " || ");} else { {fprintf(output, "(");}; firstTime = 0; }
			on1line++;
			if ( on1line > 4 ) { on1line=0; {fprintf(output, "\n");}; }
			{fprintf(output, "LA(%d)==",k);};
			if ( ((TokenInd!=0)?TokenStr[TokenInd[*e]]:TokenStr[*e]) == 0 ) {fprintf(output, "%d", *e);}
			else {fprintf(output, "%s", ((TokenInd!=0)?TokenStr[TokenInd[*e]]:TokenStr[*e]));};
		}
		free( (char *)g );
		{fprintf(output, ")");};
		if ( k>max_k ) max_k = k;
		if ( k == CLL_k ) break;
		k++;
		if ( !set_nil(fset[k]) && k<=limit ) { firstTime=1; {fprintf(output, " && ");}; }
		on1line++;
		if ( on1line > 4 ) { on1line=0; {fprintf(output, "\n");}; }
	}
	return max_k;
}









static set

genBlk( Junction *q, int jtype, int *max_k, int *need_right_curly )
# 730 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	set f;
	Junction *alt;
	int a_guess_in_block = 0;
	{if ( !(q!=0) ) fatal_intern(				"genBlk: invalid node", "/circle/s13/parrt/PCCTS/antlr/gen.c", 735);};
	{if ( !(q->ntype == 1) ) fatal_intern(	"genBlk: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 736);};

	*need_right_curly=0;
	if ( q->p2 == 0 )	
	{	
		if ( first_item_is_guess_block((Junction *)q->p1)!=0 )
		{
			warnFL("(...)? as only alternative of block is unnecessary", FileStr[q->file], q->line);
			{tab(); fprintf(output, "zzGUESS\n");};	
			{tab(); fprintf(output, "if ( !zzrv )\n");};
		}
		{if ( (q->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 747); if ( (q->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->p1))->jtype]))( q->p1 ); else (*(fpTrans[(q->p1)->ntype]))( q->p1 );};
		return empty;		
	}

	f = First(q, 1, jtype, max_k);
	for (alt=q; alt != 0; alt= (Junction *) alt->p2 )
	{
		if ( alt->p2 == 0 )					
		{	
			Node *p = alt->p1;
			if ( p->ntype == 1 )
			{
				
				if ( ((Junction *)p)->p1 == (Node *)q->end )
				{
					break;						
				}
			}
		}
		if ( alt != q ) {tab(); fprintf(output, "else ");}
		else
		{
			if ( DemandLookahead )
				if ( !GenCC ) {{tab(); fprintf(output, "LOOK(%d);\n", *max_k);};}
				else {tab(); fprintf(output, "look(%d);\n", *max_k);};
		}
		if ( alt!=q )
		{
			{fprintf(output, "{\n");};
			tabs++;
			(*need_right_curly)++;
			
			if ( a_guess_in_block )
			   	if ( !GenCC ) {{tab(); fprintf(output, "if ( zzguessing ) zzGUESS_DONE;\n");};}
				else {tab(); fprintf(output, "if ( guessing ) zzGUESS_DONE;\n");};
		}
		if ( first_item_is_guess_block((Junction *)alt->p1)!=0 )
		{
			a_guess_in_block = 1;
			{tab(); fprintf(output, "zzGUESS\n");};
		}
		{tab(); fprintf(output, "if ( ");};
		if ( first_item_is_guess_block((Junction *)alt->p1)!=0 ) {fprintf(output, "!zzrv && ");};
		genExpr(alt);
		{fprintf(output, " ) ");};
		{fprintf(output, "{\n");};
		tabs++;
		{if ( (alt->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 794); if ( (alt->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(alt->p1))->jtype]))( alt->p1 ); else (*(fpTrans[(alt->p1)->ntype]))( alt->p1 );};
		--tabs;
		{tab(); fprintf(output, "}\n");};
	}
	return f;
}

static int

has_guess_block_as_first_item( Junction *q )
# 807 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	Junction *alt;

	for (alt=q; alt != 0; alt= (Junction *) alt->p2 )
	{
		if ( first_item_is_guess_block((Junction *)alt->p1)!=0 ) return 1;
	}
	return 0;
}





Junction *

first_item_is_guess_block( Junction *q )
# 828 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	while ( q!=0 && ((q->ntype==1 && q->jtype==6) || q->ntype==4) )
	{
		if ( q->ntype==1 ) q = (Junction *)q->p1;
		else q = (Junction *) ((ActionNode *)q)->next;
	}

	if ( q==0 ) return 0;
	if ( q->ntype!=1 ) return 0;
	if ( q->jtype!=1 ) return 0;
	if ( !q->guess ) return 0;
	return q;
}




void

genAction( ActionNode *p )
# 852 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	{if ( !(p!=0) ) fatal_intern(			"genAction: invalid node and/or rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 854);};
	{if ( !(p->ntype==4) ) fatal_intern(	"genAction: not action", "/circle/s13/parrt/PCCTS/antlr/gen.c", 855);};
	
	if ( !p->done )
	{
		if ( p->is_predicate )
		{
			{tab(); fprintf(output, "if (!(");};
			
			if ( GenLineInfo && p->file != -1 ) {fprintf(output, "\n");};
			dumpAction(p->action, output, 0, p->file, p->line, 0);
			if ( p->pred_fail != 0 )
			{
				{fprintf(output, "))\n");};

				tabs++;
				{tab(); fprintf(output, "%s;\n", p->pred_fail);};
				tabs--;

			}
			else {fprintf(output, ")) {zzfailed_pred((ANTLRChar *)\"%s\");}\n",p->action);};
		}
		else
		{
			if ( FoundGuessBlk )
				if ( GenCC ) {{tab(); fprintf(output, "if ( !guessing ) {\n");};}
				else {tab(); fprintf(output, "zzNON_GUESS_MODE {\n");};
			dumpAction(p->action, output, tabs, p->file, p->line, 1);
			if ( FoundGuessBlk ) {tab(); fprintf(output, "}\n");};
		}
	}
	{if ( (p->next)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 885); if ( (p->next)->ntype == 1 ) (*(fpJTrans[((Junction *)(p->next))->jtype]))( p->next ); else (*(fpTrans[(p->next)->ntype]))( p->next );}
}








void

genRuleRef( RuleRefNode *p )
# 901 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	Junction *q;
	char *handler_id = "";
	RuleEntry *r, *r2;
	char *parm = "", *exsig = "";
	{if ( !(p!=0) ) fatal_intern(			"genRuleRef: invalid node and/or rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 907);};
	{if ( !(p->ntype==2) ) fatal_intern( "genRuleRef: not rule reference", "/circle/s13/parrt/PCCTS/antlr/gen.c", 908);};
	
	if ( p->altstart!=0 && p->altstart->exception_label!=0 )
		handler_id = p->altstart->exception_label;

	r = (RuleEntry *) hash_get(Rname, p->text);
	if ( r == 0 )
	{
		warnFL( 
# 917 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
eMsg3("rule %s not defined", 					  p->text,0,0), FileStr[p->file], p->line );
		return;
	}
	r2 = (RuleEntry *) hash_get(Rname, p->rname);
	if ( r2 == 0 ) {warnNoFL("Rule hash table is screwed up beyond belief"); return;}

	if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", p->line, FileStr[p->file]);

	if ( GenCC && GenAST ) {
		{tab(); fprintf(output, "_ast = NULL;\n");};
	}

	if ( FoundGuessBlk && p->assign!=0 )
		if ( GenCC ) {{tab(); fprintf(output, "if ( !guessing ) {\n");};}
		else {tab(); fprintf(output, "zzNON_GUESS_MODE {\n");};

	if ( FoundException ) exsig = "&_signal";

	tab();
	if ( GenAST )
	{
		if ( GenCC ) {


			{

				parm = "&_ast";
			}









		}
		else {
			if ( r2->noAST || p->astnode==0 )
			{
				{fprintf(output, "_ast = NULL; ");};
				parm = "&_ast";
			}
			else parm = "zzSTR";
		}
		if ( p->assign!=0 )
		{
			if ( !HasComma(p->assign) ) {{fprintf(output, "%s = ",p->assign);};}
			else {fprintf(output, "{ struct _rv%d _trv; _trv = ", r->rulenum);};
		}
		if ( FoundException ) {
			
# 974 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{fprintf(output, "%s%s(%s,&_signal%s%s); ", 				  RulePrefix, 				  p->text, 				  parm, 				  (p->parms!=0)?",":"", 				  (p->parms!=0)?p->parms:"");};
			if ( p->ex_group!=0 ) {
				{fprintf(output, "\n");};
				{tab(); fprintf(output, "if (_signal) {\n");};
				tabs++;
				dumpException(p->ex_group, 0);
				tabs--;
				{tab(); fprintf(output, "}");};
			}
			else {
				{fprintf(output, "if (_signal) goto %s_handler;", handler_id);};
			}
		}
		else {
			
# 993 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{fprintf(output, "%s%s(%s%s%s);", 				  RulePrefix, 				  p->text, 				  parm, 				  (p->parms!=0)?",":"", 				  (p->parms!=0)?p->parms:"");};
		}
		if ( GenCC && (r2->noAST || p->astnode==0) )
		{
			
			
			{fprintf(output, "\n");};
			{tab(); fprintf(output, "_ast%d%d = (AST *)_ast;", BlkLevel-1, p->elnum);};
		}
		else if ( !r2->noAST && p->astnode == 3 )
		{
			
			if ( GenCC ) {
				{fprintf(output, "\n");};
				{tab(); fprintf(output, "if ( _tail==NULL ) _sibling = _ast; else _tail->setRight(_ast);\n");};
				{tab(); fprintf(output, "_ast%d%d = (AST *)_ast;\n", BlkLevel-1, p->elnum);};
				tab();
			}
			else {fprintf(output, " ");};
			if ( GenCC ) {{fprintf(output, "ASTBase::");};} else {fprintf(output, "zz");};
			{fprintf(output, "link(_root, &_sibling, &_tail);");};
		}
	}
	else
	{
		if ( p->assign!=0 )
		{
			if ( !HasComma(p->assign) ) {{fprintf(output, "%s = ",p->assign);};}
			else {fprintf(output, "{ struct _rv%d _trv; _trv = ", r->rulenum);};
		}
		if ( FoundException ) {
			
# 1028 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{fprintf(output, "%s%s(&_signal%s%s); ", 				  RulePrefix, 				  p->text, 				  (p->parms!=0)?",":"", 				  (p->parms!=0)?p->parms:"");};
			if ( p->ex_group!=0 ) {
				{fprintf(output, "\n");};
				{tab(); fprintf(output, "if (_signal) {\n");};
				tabs++;
				dumpException(p->ex_group, 0);
				tabs--;
				{tab(); fprintf(output, "}");};
			}
			else {
				{fprintf(output, "if (_signal) goto %s_handler;", handler_id);};
			}
		}
		else {
			
# 1045 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{fprintf(output, "%s%s(%s);", 				  RulePrefix, 				  p->text, 				  (p->parms!=0)?p->parms:"");};
		}
		if ( p->assign!=0 ) {fprintf(output, "\n");};
	}
	q = RulePtr[r->rulenum];	
	if ( p->assign!=0 ) {
		if ( HasComma(p->assign) )
		{
			{fprintf(output, "\n");};
			dumpRetValAssign(p->assign, q->ret);
			{fprintf(output, "}");};
		}
	}
	{fprintf(output, "\n");};

	
	if ( p->el_label!=0 )
	{
		if ( GenAST )
		{
			if ( GenCC ) {
				{tab(); fprintf(output, "%s_ast = _ast%d%d;\n", p->el_label, BlkLevel-1, p->elnum);};
			}
			else {{tab(); fprintf(output, "%s_ast = zzastCur;\n", p->el_label);};}
		}
	}

	if ( FoundGuessBlk && p->assign!=0 ) {
		
		{tab(); fprintf(output, "} else {\n");};
		if ( FoundException ) {
			
# 1082 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "%s%s(%s%s&_signal%s%s);\n", 				 RulePrefix, 				 p->text, 				 parm,                  (*parm!='\0')?",":"",                  (p->parms!=0)?",":"", 				 (p->parms!=0)?p->parms:"");};
		}
		else {
			
# 1090 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "%s%s(%s%s%s);\n", 				 RulePrefix, 				 p->text, 				 parm, 				 (p->parms!=0 && *parm!='\0')?",":"", 				 (p->parms!=0)?p->parms:"");};
		}
		{tab(); fprintf(output, "}\n");};
	}
	{if ( (p->next)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1094); if ( (p->next)->ntype == 1 ) (*(fpJTrans[((Junction *)(p->next))->jtype]))( p->next ); else (*(fpTrans[(p->next)->ntype]))( p->next );}
}







void

genToken( TokNode *p )
# 1109 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	TermEntry *tcsym;
	RuleEntry *r;
	char *handler_id = "";
	ActionNode *a;
	{if ( !(p!=0) ) fatal_intern(			"genToken: invalid node and/or rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1115);};
	{if ( !(p->ntype==3) ) fatal_intern(	"genToken: not token", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1116);};
	
	if ( p->altstart!=0 && p->altstart->exception_label!=0 )
		handler_id = p->altstart->exception_label;

	r = (RuleEntry *) hash_get(Rname, p->rname);
	if ( r == 0 ) {warnNoFL("Rule hash table is screwed up beyond belief"); return;}

	if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", p->line, FileStr[p->file]);

	if ( !set_nil(p->tset) )
	{
		unsigned e;
		set b;
		b = set_dup(p->tset);
# 1135 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

		if ( p->tclass->dumped ) e = p->tclass->setnum;

		else {
			e = DefErrSet(&b, 0, ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]));
			p->tclass->dumped = 1;		
# 1143 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

			p->tclass->setnum = e;

		}
		if ( !FoundException )
			{{tab(); fprintf(output, "zzsetmatch(%s_set);", ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]));};}
		else {
            if ( p->use_def_MT_handler )
                
# 1154 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "zzsetmatch_wdfltsig(%s_set,(TokenType)%d,%s);",                      ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]),                      p->token,                      tokenFollowSet(p));}
            else
                
# 1158 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "zzsetmatch_wsig(%s_set, %s_handler);",                      ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]),                      handler_id);};
		}
		{if ( (b).setword != 0 ) free((char *)((b).setword)); (b) = empty;};
	}
	else if ( ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token])!=0 )
	{
        if ( FoundException ) {
            if ( p->use_def_MT_handler )
                {tab(); fprintf(output, "zzmatch_wdfltsig(%s,%s);",((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]),tokenFollowSet(p));}
            else
                
# 1170 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "zzmatch_wsig(%s, %s_handler);",                      ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]),                      handler_id);};
        }
		else {tab(); fprintf(output, "zzmatch(%s);", ((TokenInd!=0)?TokenStr[TokenInd[p->token]]:TokenStr[p->token]));};
	}
	else {
        if ( FoundException ) {
            if ( p->use_def_MT_handler )
				
# 1178 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "zzmatch_wdfltsig((TokenType)%d,%s);", 					 p->token,tokenFollowSet(p));}
            else
                {tab(); fprintf(output, "zzmatch_wsig(%d,%s_handler);",p->token,handler_id);};
        }
		else {{tab(); fprintf(output, "zzmatch(%d);", p->token);};}
	}

	a = findImmedAction( p->next );
	
	if ( GenCC && p->elnum>0 )
	{
		
		if ( set_el(p->elnum, tokensRefdInBlock) || GenAST ) {
			if ( !DontCopyTokens )
				{{fprintf(output, " *_t%d%d = *((ANTLRToken *)LT(1));", BlkLevel-1, p->elnum);};}
			else
				{fprintf(output, " _t%d%d = (ANTLRToken *)LT(1);", BlkLevel-1, p->elnum);};
		}
		if ( LL_k>1 )
			if ( !DemandLookahead ) {fprintf(output, " labase++;");};
		{fprintf(output, "\n");};
		tab();
	}
	if ( GenAST )
	{
		if ( FoundGuessBlk && !(p->astnode == 0 || r->noAST) )
		{
			if ( GenCC ) {{fprintf(output, "if ( !guessing ) {\n");}; tab();}
			else {{fprintf(output, "zzNON_GUESS_MODE {\n");}; tab();}
		}
		if ( !r->noAST )
		{
			if ( GenCC && !(p->astnode == 0 || r->noAST) ) {
				{fprintf(output, "\n");};
				{tab(); fprintf(output, "_ast%d%d = new AST(_t%d%d);\n", BlkLevel-1, p->elnum, BlkLevel-1, p->elnum);};
				tab();
			}
			if ( GenCC && !(p->astnode == 0 || r->noAST) )
				{{fprintf(output, "_ast%d%d->", BlkLevel-1, p->elnum);};}
			else {fprintf(output, " ");};
			if ( p->astnode==1 ) {
				if ( !GenCC ) {fprintf(output, "zz");};
				{fprintf(output, "subchild(_root, &_sibling, &_tail);");};
			}
			else if ( p->astnode==2 ) {
				if ( !GenCC ) {fprintf(output, "zz");};
				{fprintf(output, "subroot(_root, &_sibling, &_tail);");};
			}
			if ( GenCC && !(p->astnode == 0 || r->noAST) ) {
				{fprintf(output, "\n");};
				tab();
			}
		}
		else if ( !GenCC ) {fprintf(output, " zzastDPush;");};
		if ( FoundGuessBlk && !(p->astnode == 0 || r->noAST) )
			{{fprintf(output, "}\n");}; tab();}
	}

	
	if ( p->el_label!=0 )
	{
		{fprintf(output, "\n");};
		if ( FoundGuessBlk )
		{
			if ( GenCC ) {{tab(); fprintf(output, "if ( !guessing ) {\n");}; tab();}
			else {{tab(); fprintf(output, "zzNON_GUESS_MODE {\n");}; tab();}
		}
		
		if ( GenCC ) {
			if ( set_el(p->elnum, tokensRefdInBlock) || GenAST )
				{{tab(); fprintf(output, "%s = _t%d%d;\n", p->el_label, BlkLevel-1, p->elnum);};}
			else
				{{tab(); fprintf(output, "%s = (ANTLRToken *)LT(1);\n", p->el_label);};}
		}
		else {{tab(); fprintf(output, "%s = zzaCur;\n", p->el_label);};}
		
		if ( GenAST && !(p->astnode == 0 || r->noAST) )
		{
			if ( GenCC ) {
				{tab(); fprintf(output, "%s_ast = _ast%d%d;\n", p->el_label, BlkLevel-1, p->elnum);};
			}
			else {{tab(); fprintf(output, "%s_ast = zzastCur;\n", p->el_label);};}
		}

		if ( FoundGuessBlk ) {{fprintf(output, "}\n");}; tab();}
	}

	
	if ( a != 0 )
	{
		
		{fprintf(output, "\n");};
		if ( a->is_predicate )
		{
			{tab(); fprintf(output, "if (!(");};
			dumpAction(a->action, output, 0, a->file, a->line, 0);
			if ( a->pred_fail != 0 )
			{
				{fprintf(output, "))\n");};


				tabs++;
				{tab(); fprintf(output, "%s;\n", a->pred_fail);};
				tabs--;

			}
			else {fprintf(output, ")) {zzfailed_pred((ANTLRChar *)\"%s\");}\n",a->action);};
		}
		else
		{
			if ( FoundGuessBlk )
				if ( GenCC ) {{tab(); fprintf(output, "if ( !guessing ) {\n");};}
				else {tab(); fprintf(output, "zzNON_GUESS_MODE {\n");};
			dumpAction(a->action, output, tabs, a->file, a->line, 1);
			if ( FoundGuessBlk ) {tab(); fprintf(output, "}\n");};
		}
		a->done = 1;
		if ( !DemandLookahead ) {
			if ( GenCC ) {
				if ( FoundException && p->use_def_MT_handler ) {tab(); fprintf(output, "if (!_signal)");};
				{fprintf(output, " consume();");}
                if ( FoundException && p->use_def_MT_handler )
                    {fprintf(output, " _signal=NoSignal;");};
                {fprintf(output, "\n");};
			}
            else {
                if ( FoundException && p->use_def_MT_handler ) {fprintf(output, "if (!_signal)");};
					{fprintf(output, " zzCONSUME;\n");};
                if ( FoundException && p->use_def_MT_handler ) {fprintf(output, " _signal=NoSignal;");};
                {fprintf(output, "\n");};
            }
		}
		else {tab(); fprintf(output, "\n");};
		{if ( ( a->next )==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1311); if ( ( a->next )->ntype == 1 ) (*(fpJTrans[((Junction *)( a->next ))->jtype]))(  a->next  ); else (*(fpTrans[( a->next )->ntype]))(  a->next  );};
	}
	else
	{
        if ( !DemandLookahead ) {
			if ( GenCC ) {
				if (FoundException && p->use_def_MT_handler) {fprintf(output, "if (!_signal)");};
				{fprintf(output, " consume();");}
				if (FoundException&&p->use_def_MT_handler) {fprintf(output, " _signal=NoSignal;");};
				{fprintf(output, "\n");};
			}
			else {
				if (FoundException && p->use_def_MT_handler) {fprintf(output, "if (!_signal)");};
				{fprintf(output, " zzCONSUME;");};
				if ( FoundException && p->use_def_MT_handler ) {fprintf(output, " _signal=NoSignal;");};
				{fprintf(output, "\n");};
			}
		}
		else {fprintf(output, "\n");};
		{if ( (p->next)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1330); if ( (p->next)->ntype == 1 ) (*(fpJTrans[((Junction *)(p->next))->jtype]))( p->next ); else (*(fpTrans[(p->next)->ntype]))( p->next );};
	}
}

void

genOptBlk( Junction *q )
# 1340 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int max_k;
	set f;
	int need_right_curly;
	set savetkref;
	savetkref = tokensRefdInBlock;
	{if ( !(q!=0) ) fatal_intern(				"genOptBlk: invalid node and/or rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1347);};
	{if ( !(q->ntype == 1) ) fatal_intern(	"genOptBlk: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1348);};
	{if ( !(q->jtype == 2) ) fatal_intern(	"genOptBlk: not optional block", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1349);};

	if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", q->line, FileStr[q->file]);
	BLOCK_Preamble(q);
	BlkLevel++;
	f = genBlk(q, 2, &max_k, &need_right_curly);
	{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
	freeBlkFsets(q);
	BlkLevel--;
    if ( first_item_is_guess_block((Junction *)q->p1)!=0 )
	{
		if ( !GenCC ) {{tab(); fprintf(output, "else if ( zzguessing ) zzGUESS_DONE;\n");};}
		else {tab(); fprintf(output, "else if ( guessing ) zzGUESS_DONE;\n");};
	}
	{ int i; for (i=1; i<=need_right_curly; i++) {tabs--; {tab(); fprintf(output, "}\n");};} }
	BLOCK_Tail();
	if (q->end->p1 != 0) {if ( (q->end->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1365); if ( (q->end->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->end->p1))->jtype]))( q->end->p1 ); else (*(fpTrans[(q->end->p1)->ntype]))( q->end->p1 );};
	tokensRefdInBlock = savetkref;
}








void

genLoopBlk( Junction *begin, Junction *q, Junction *start, int max_k )
# 1385 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	set f;
	int need_right_curly;
	set savetkref;
	savetkref = tokensRefdInBlock;
	{if ( !(q->ntype == 1) ) fatal_intern(	"genLoopBlk: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1391);};
	{if ( !(q->jtype == 3) ) fatal_intern(	"genLoopBlk: not loop block", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1392);};

	if ( q->visited ) return;
	q->visited = 1;
	if ( q->p2 == 0 )	
	{
		if ( DemandLookahead )
			if ( !GenCC ) {{tab(); fprintf(output, "LOOK(%d);\n", max_k);};}
			else {tab(); fprintf(output, "look(%d);\n", max_k);};
		{tab(); fprintf(output, "while ( ");};
		if ( begin!=0 ) genExpr(begin);
		else genExpr(q);
		


		if ( ParseWithPredicates && begin->predicate==0 )
		{
			Predicate *a = find_predicates((Node *)q->p1);
			if ( a!=0 )
			{
				{fprintf(output, "&&");};
				genPredTree(a, q);
			}
		}
		{fprintf(output, " ) {\n");};
		tabs++;
		{if ( (q->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1418); if ( (q->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->p1))->jtype]))( q->p1 ); else (*(fpTrans[(q->p1)->ntype]))( q->p1 );};
		if ( !GenCC ) {tab(); fprintf(output, "zzLOOP(zztasp%d);\n", BlkLevel-1);};
		if ( DemandLookahead )
			if ( !GenCC ) {{tab(); fprintf(output, "LOOK(%d);\n", max_k);};}
			else {tab(); fprintf(output, "look(%d);\n", max_k);};
		--tabs;
		{tab(); fprintf(output, "}\n");};
		freeBlkFsets(q);
		q->visited = 0;
		tokensRefdInBlock = savetkref;
		return;
	}
	{tab(); fprintf(output, "while ( 1 ) {\n");};
	tabs++;
	if ( begin!=0 )
	{
		if ( DemandLookahead )
		{
			if ( !GenCC ) {{tab(); fprintf(output, "LOOK(%d);\n", max_k);};}
			else {tab(); fprintf(output, "look(%d);\n", max_k);};
		}
		




		{tab(); fprintf(output, "if ( !(");};









		genExpr((Junction *)begin);
		{fprintf(output, ")) break;\n");};
	}
	f = genBlk(q, 3, &max_k, &need_right_curly);
	{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
	freeBlkFsets(q);

	
	if ( begin==0 ) {tab(); fprintf(output, "else break;\n");}; 

	{ int i; for (i=1; i<=need_right_curly; i++) {tabs--; {tab(); fprintf(output, "}\n");};} }
	if ( !GenCC ) {tab(); fprintf(output, "zzLOOP(zztasp%d);\n", BlkLevel-1);};
	--tabs;
	{tab(); fprintf(output, "}\n");};
	q->visited = 0;
	tokensRefdInBlock = savetkref;
}




























void

genLoopBegin( Junction *q )
# 1505 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	set f;
	int i;
	int max_k;
	set savetkref;
	savetkref = tokensRefdInBlock;
	{if ( !(q!=0) ) fatal_intern(				"genLoopBegin: invalid node and/or rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1512);};
	{if ( !(q->ntype == 1) ) fatal_intern(	"genLoopBegin: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1513);};
	{if ( !(q->jtype == 9) ) fatal_intern(	"genLoopBegin: not loop block", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1514);};
	{if ( !(q->p2!=0) ) fatal_intern(			"genLoopBegin: invalid Loop Graph", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1515);};

	if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", q->line, FileStr[q->file]);

	BLOCK_Preamble(q);
	BlkLevel++;
	f = First(q, 1, 9, &max_k);
	
	if ( LL_k>1 && !set_nil(q->fset[2]) )
		genLoopBlk( q, (Junction *)q->p1, q, max_k );
	else genLoopBlk( q, (Junction *)q->p1, 0, max_k );

	for (i=1; i<=CLL_k; i++) {if ( (q->fset[i]).setword != 0 ) free((char *)((q->fset[i]).setword)); (q->fset[i]) = empty;};
	for (i=1; i<=CLL_k; i++) {if ( (((Junction *)q->p2)->fset[i]).setword != 0 ) free((char *)((((Junction *)q->p2)->fset[i]).setword)); (((Junction *)q->p2)->fset[i]) = empty;};
	--BlkLevel;
	BLOCK_Tail();
	{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
	if (q->end->p1 != 0) {if ( (q->end->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1532); if ( (q->end->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->end->p1))->jtype]))( q->end->p1 ); else (*(fpTrans[(q->end->p1)->ntype]))( q->end->p1 );};
	tokensRefdInBlock = savetkref;
}
























void

genPlusBlk( Junction *q )
# 1565 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int max_k;
	set f;
	int need_right_curly;
	set savetkref;
	savetkref = tokensRefdInBlock;
	{if ( !(q!=0) ) fatal_intern(				"genPlusBlk: invalid node and/or rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1572);};
	{if ( !(q->ntype == 1) ) fatal_intern(	"genPlusBlk: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1573);};
	{if ( !(q->jtype == 8) ) fatal_intern(	"genPlusBlk: not Plus block", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1574);};
	{if ( !(q->p2 != 0) ) fatal_intern(			"genPlusBlk: not a valid Plus block", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1575);};

	if ( q->visited ) return;
	q->visited = 1;
	if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", q->line, FileStr[q->file]);
	BLOCK_Preamble(q);
	BlkLevel++;
	



	if ( ((Junction *)q->p2)->p2 == 0 &&
		 ((Junction *)q->p2)->ignore )			
	{
		Predicate *a=0;
		


		if ( ParseWithPredicates )
		{
			a = find_predicates((Node *)q);
			if ( a!=0 ) {
				{tab(); fprintf(output, "if (");};
				genPredTree(a, q);
				{fprintf(output, ") {\n");};
			}
		}
		{tab(); fprintf(output, "do {\n");};
		tabs++;
		{if ( (q->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1604); if ( (q->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->p1))->jtype]))( q->p1 ); else (*(fpTrans[(q->p1)->ntype]))( q->p1 );};
		if ( !GenCC ) {tab(); fprintf(output, "zzLOOP(zztasp%d);\n", BlkLevel-1);};
		f = First(q, 1, 8, &max_k);
		if ( DemandLookahead )
			if ( !GenCC ) {{tab(); fprintf(output, "LOOK(%d);\n", max_k);};}
			else {tab(); fprintf(output, "look(%d);\n", max_k);};
		--tabs;
		{tab(); fprintf(output, "} while ( ");};
		if ( q->parm!=0 && q->predparm ) {fprintf(output, "(%s) && ", q->parm);};
		genExpr(q);
		if ( ParseWithPredicates && a!=0 )
		{
			{fprintf(output, "&&");};
			genPredTree(a, q);
		}
		{fprintf(output, " );\n");};
		if ( ParseWithPredicates && a!=0 ) {tab(); fprintf(output, "}\n");};
		--BlkLevel;
		BLOCK_Tail();
		q->visited = 0;
		freeBlkFsets(q);
		{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
		if (q->end->p1 != 0) {if ( (q->end->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1626); if ( (q->end->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->end->p1))->jtype]))( q->end->p1 ); else (*(fpTrans[(q->end->p1)->ntype]))( q->end->p1 );};
		tokensRefdInBlock = savetkref;
		return;
	}
	{tab(); fprintf(output, "do {\n");};
	tabs++;
	f = genBlk(q, 8, &max_k, &need_right_curly);
	{tab(); fprintf(output, "else if ( zzcnt>1 ) break; /* implied exit branch */\n");};
	tab();
	makeErrorClause(q,f,max_k);
	{ int i; for (i=1; i<=need_right_curly; i++) {tabs--; {tab(); fprintf(output, "}\n");};} }
	freeBlkFsets(q);
	{tab(); fprintf(output, "zzcnt++;");};
	if ( !GenCC ) {fprintf(output, " zzLOOP(zztasp%d);", BlkLevel-1);};
	{fprintf(output, "\n");};
	if ( DemandLookahead )
		if ( !GenCC ) {{tab(); fprintf(output, "LOOK(%d);\n", max_k);};}
		else {tab(); fprintf(output, "look(%d);\n", max_k);};
	--tabs;
	if ( q->parm!=0 && q->predparm ) {{tab(); fprintf(output, "} while (%s);\n", q->parm);};}
	else {tab(); fprintf(output, "} while ( 1 );\n");};
	--BlkLevel;
	BLOCK_Tail();
	q->visited = 0;
	if (q->end->p1 != 0) {if ( (q->end->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1650); if ( (q->end->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->end->p1))->jtype]))( q->end->p1 ); else (*(fpTrans[(q->end->p1)->ntype]))( q->end->p1 );};
	tokensRefdInBlock = savetkref;
}
































void

genSubBlk( Junction *q )
# 1691 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int max_k;
	set f;
	int need_right_curly;
	set savetkref;
	savetkref = tokensRefdInBlock;
	{if ( !(q->ntype == 1) ) fatal_intern(	"genSubBlk: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1698);};
	{if ( !(q->jtype == 1) ) fatal_intern(	"genSubBlk: not subblock", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1699);};

	if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", q->line, FileStr[q->file]);
	BLOCK_Preamble(q);
	BlkLevel++;
	f = genBlk(q, 1, &max_k, &need_right_curly);
	if ( q->p2 != 0 ) {tab(); makeErrorClause(q,f,max_k);}
	{ int i; for (i=1; i<=need_right_curly; i++) {tabs--; {tab(); fprintf(output, "}\n");};} }
	freeBlkFsets(q);
	--BlkLevel;
	BLOCK_Tail();

	if ( q->guess )
	{
		{tab(); fprintf(output, "zzGUESS_DONE\n");};
	}

	

	if ( q->guess && analysis_point(q)==q )
	{
		if ( GenLineInfo ) fprintf(output, "# %d \"%s\"\n", q->line, FileStr[q->file]);
		BLOCK_Preamble(q);
		BlkLevel++;
		f = genBlk(q, 1, &max_k, &need_right_curly);
		if ( q->p2 != 0 ) {tab(); makeErrorClause(q,f,max_k);}
		{ int i; for (i=1; i<=need_right_curly; i++) {tabs--; {tab(); fprintf(output, "}\n");};} }
		freeBlkFsets(q);
		--BlkLevel;
		BLOCK_Tail();
	}

	if (q->end->p1 != 0) {if ( (q->end->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1731); if ( (q->end->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->end->p1))->jtype]))( q->end->p1 ); else (*(fpTrans[(q->end->p1)->ntype]))( q->end->p1 );};
	tokensRefdInBlock = savetkref;
}
















void

genRule( Junction *q )
# 1756 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	int max_k;
	set follow, rk, f;
	ActionNode *a;
	RuleEntry *r;
	static int file = -1;
	int need_right_curly;
	{if ( !(q->ntype == 1) ) fatal_intern(	"genRule: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1764);};
	{if ( !(q->jtype == 5) ) fatal_intern(	"genRule: not rule", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1765);};

	r = (RuleEntry *) hash_get(Rname, q->rname);
	if ( r == 0 ) warnNoFL("Rule hash table is screwed up beyond belief");
	if ( q->file != file )		
	{
		if ( output != 0 ) fclose( output );
		output = fopen(OutMetaName(outname(FileStr[q->file])), "w");
		{if ( !(output != 0) ) fatal_intern( "genRule: can't open output file", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1773);};

		special_fopen_actions(OutMetaName(outname(FileStr[q->file])));

		if ( file == -1 ) genHdr1(q->file);
		else genHdr(q->file);
		file = q->file;
	}
	DumpFuncHeader(q,r);
	tabs++;
	if ( q->ret!=0 )
	{
		if ( HasComma(q->ret) ) {{tab(); fprintf(output, "struct _rv%d _retv;\n",r->rulenum);};}
		else
		{
			tab();
			DumpType(q->ret, output);
			{tab(); fprintf(output, " _retv;\n");};
		}
	}

	if ( GenLineInfo )
	{
		fprintf(output, "# %d \"%s\"\n", q->line, FileStr[q->file]);
	}

	{tab(); fprintf(output, "zzRULE;\n");};
	if ( FoundException )
	{
		{tab(); fprintf(output, "int _sva=1;\n");};
	}
	if ( GenCC && GenAST )
		{tab(); fprintf(output, "ASTBase **_astp, *_ast = NULL, *_sibling = NULL, *_tail = NULL;\n");};
	if ( GenCC ) genTokenPointers(q);
	if ( GenCC&&GenAST ) genASTPointers(q);
	if ( q->el_labels!=0 ) genElementLabels(q->el_labels);
	if ( FoundException ) {tab(); fprintf(output, "int _signal=NoSignal;\n");};
	if ( !GenCC ) {tab(); fprintf(output, "zzBLOCK(zztasp%d);\n", BlkLevel);};
	if ( !GenCC ) {tab(); fprintf(output, "zzMake0;\n");};
	if ( FoundException ) {tab(); fprintf(output, "*_retsignal = NoSignal;\n");};
	if ( !GenCC ) {tab(); fprintf(output, "{\n");};

	if ( has_guess_block_as_first_item((Junction *)q->p1) )
	{
		{tab(); fprintf(output, "zzGUESS_BLOCK\n");};
	}

	
	if ( ((Junction *)q->p1)->jtype == 1 )
		a = findImmedAction( ((Junction *)q->p1)->p1 );
	else
		a = findImmedAction( q->p1 );	
	if ( a!=0 && !a->is_predicate )
	{
		dumpAction(a->action, output, tabs, a->file, a->line, 1);
		a->done = 1;	
	}
	if ( TraceGen )
		if ( GenCC ) {{tab(); fprintf(output, "tracein(\"%s\");\n", q->rname);};}
		else {tab(); fprintf(output, "zzTRACEIN((ANTLRChar *)\"%s\");\n", q->rname);};

	BlkLevel++;
	q->visited = 1;				
	f = genBlk((Junction *)q->p1, 5, &max_k, &need_right_curly);
	if ( q->p1 != 0 )
		if ( ((Junction *)q->p1)->p2 != 0 )
			{tab(); makeErrorClause((Junction *)q->p1,f,max_k);}
	{ int i; for (i=1; i<=need_right_curly; i++) {tabs--; {tab(); fprintf(output, "}\n");};} }
	freeBlkFsets((Junction *)q->p1);
	q->visited = 0;
	--BlkLevel;
	if ( !GenCC ) {tab(); fprintf(output, "zzEXIT(zztasp%d);\n", BlkLevel);};

	if ( TraceGen )
		if ( GenCC ) {{tab(); fprintf(output, "traceout(\"%s\");\n", q->rname);};}
		else {tab(); fprintf(output, "zzTRACEOUT((ANTLRChar *)\"%s\");\n", q->rname);};

	if ( q->ret!=0 ) {tab(); fprintf(output, "return _retv;\n");} else {tab(); fprintf(output, "return;\n");};
	
	NewSet();
	rk = empty;
	{if ( (q->end)==0 ) fatalFL("REACH: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1854); ( follow) = (*(fpReach[(q->end)->ntype]))( q->end,  1,  &rk );};
	FillSet( follow );
	{if ( ( follow ).setword != 0 ) free((char *)(( follow ).setword)); ( follow ) = empty;};

	{fprintf(output, "fail:\n");};
	if ( !GenCC ) {tab(); fprintf(output, "zzEXIT(zztasp1);\n");};
	if ( FoundGuessBlk )
	   	if ( !GenCC ) {{tab(); fprintf(output, "if ( zzguessing ) zzGUESS_FAIL;\n");};}
		else {tab(); fprintf(output, "if ( guessing ) zzGUESS_FAIL;\n");};
	if ( q->erraction!=0 )
		dumpAction(q->erraction, output, tabs, q->file, q->line, 1);
	if ( GenCC )
	{
		
# 1868 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "syn(zzBadTok, %s, zzMissSet, zzMissTok, zzErrk);\n", 			 r->egroup==0?"(ANTLRChar *)\"\"":r->egroup);};
	}
	else
	{
		
# 1873 "/circle/s13/parrt/PCCTS/antlr/gen.c" 
{tab(); fprintf(output, "zzsyn(zzMissText, zzBadTok, %s, zzMissSet, zzMissTok, zzErrk, zzBadText);\n", 			 r->egroup==0?"(ANTLRChar *)\"\"":r->egroup);};
	}
	{tab(); fprintf(output, "%sresynch(setwd%d, 0x%x);\n", GenCC?"":"zz", wordnum, 1<<setnum);};

	if ( TraceGen )
		if ( GenCC ) {{tab(); fprintf(output, "traceout(\"%s\");\n", q->rname);};}
		else {tab(); fprintf(output, "zzTRACEOUT((ANTLRChar *)\"%s\");\n", q->rname);};

	if ( q->ret!=0 ) {{tab(); fprintf(output, "return _retv;\n");};}
	else if ( q->exceptions!=0 ) {tab(); fprintf(output, "return;\n");};
	if ( !GenCC ) {tab(); fprintf(output, "}\n");};

	
	if ( q->exceptions!=0 )
	{
		{tab(); fprintf(output, "/* exception handlers */\n");};
		dumpExceptions(q->exceptions);
        if ( !r->has_rule_exception )
        {
            {fprintf(output, "_handler:\n");};
            {tab(); fprintf(output, "zzdflthandlers(_signal,_retsignal);\n");};
        }
		{fprintf(output, "_adios:\n");};
		if ( q->ret!=0 ) {{tab(); fprintf(output, "return _retv;\n");};}
		else {{tab(); fprintf(output, "return;\n");};}
	}
	else if ( FoundException )
	{
        {fprintf(output, "_handler:\n");};
        {tab(); fprintf(output, "zzdflthandlers(_signal,_retsignal);\n");};
	}

	tabs--;
	{tab(); fprintf(output, "}\n");};

	if ( q->p2 != 0 ) {{if ( (q->p2)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 1908); if ( (q->p2)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->p2))->jtype]))( q->p2 ); else (*(fpTrans[(q->p2)->ntype]))( q->p2 );};} 
	else dumpAfterActions( output );
}

static void

DumpFuncHeader( Junction *q, RuleEntry *r )
# 1919 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	
	{fprintf(output, "\n");};
	if ( q->ret!=0 )
	{
		if ( HasComma(q->ret) )
		{
			if (GenCC) {tab(); fprintf(output, "%s::_rv%d\n", CurrentClassName, r->rulenum);}
			else {tab(); fprintf(output, "struct _rv%d\n",r->rulenum);};
		}
		else
		{
			DumpType(q->ret, output);
			{tab(); fprintf(output, "\n");};
		}
	}
	else
	{
		{fprintf(output, "void\n");};
	}
	if ( !GenCC ) {fprintf(output, "#ifdef __STDC__\n");};
	if ( !GenCC ) {tab(); fprintf(output, "%s%s(", RulePrefix, q->rname);}
	else {tab(); fprintf(output, "%s::%s(", CurrentClassName, q->rname);};
	DumpANSIFunctionArgDef(output,q);
	{fprintf(output, "\n");};

	if ( GenCC ) {{tab(); fprintf(output, "{\n");}; return;}

	
	{tab(); fprintf(output, "#else\n");};
	{tab(); fprintf(output, "%s%s(", RulePrefix, q->rname);};
	if ( GenAST )
	{
		{fprintf(output, "_root");};
		if ( q->pdecl!=0 ) {fprintf(output, ",");};
	}
	if ( FoundException )
	{
		if ( GenAST ) {fprintf(output, ",");};
		{fprintf(output, "_retsignal");};
		if ( q->pdecl!=0 ) {fprintf(output, ",");};
	}

	DumpListOfParmNames( q->pdecl, output );
	{tab(); fprintf(output, ")\n");};
	if ( GenAST ) {tab(); fprintf(output, "AST **_root;\n");};
	if ( FoundException ) {tab(); fprintf(output, "int *_retsignal;\n");};
	DumpOldStyleParms( q->pdecl, output );
	{tab(); fprintf(output, "#endif\n");};
	{tab(); fprintf(output, "{\n");};
}

void

DumpANSIFunctionArgDef(struct _iobuf *f, Junction *q)
# 1979 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	if ( GenAST )
	{
		if ( GenCC ) {fprintf(f,"ASTBase **_root");}
		else fprintf(f,"AST**_root");
		if ( q->pdecl!=0 ) fprintf(f,",");
	}
	if ( FoundException )
	{
		if ( GenAST ) fprintf(f,",");
		fprintf(f,"int *_retsignal");
		if ( q->pdecl!=0 ) fprintf(f,",");
	}
	if ( q->pdecl!=0 ) {fprintf(f,"%s", q->pdecl);}
	else if ( !GenAST && !FoundException ) fprintf(f,"void");
	fprintf(f,")");
}

void

genJunction( Junction *q )
# 2004 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	{if ( !(q->ntype == 1) ) fatal_intern(	"genJunction: not junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2006);};
	{if ( !(q->jtype == 6) ) fatal_intern(	"genJunction: not generic junction", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2007);};

	if ( q->p1 != 0 ) {if ( (q->p1)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2009); if ( (q->p1)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->p1))->jtype]))( q->p1 ); else (*(fpTrans[(q->p1)->ntype]))( q->p1 );};
	if ( q->p2 != 0 ) {if ( (q->p2)==0 ) fatalFL("TRANS: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2010); if ( (q->p2)->ntype == 1 ) (*(fpJTrans[((Junction *)(q->p2))->jtype]))( q->p2 ); else (*(fpTrans[(q->p2)->ntype]))( q->p2 );};
}

void

genEndBlk( Junction *q )
# 2019 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
}

void

genEndRule( Junction *q )
# 2029 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
}

void

genHdr( int file )
# 2039 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	{fprintf(output, "/*\n");};
	{fprintf(output, " * A n t l r  T r a n s l a t i o n  H e a d e r\n");};
	{fprintf(output, " *\n");};
	{fprintf(output, " * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994\n");};
	{fprintf(output, " * Purdue University Electrical Engineering\n");};
	{fprintf(output, " * With AHPCRC, University of Minnesota\n");};
	{fprintf(output, " * ANTLR Version %s\n", Version);};
	{fprintf(output, " */\n");};
	{fprintf(output, "#include <stdio.h>\n");};
	{fprintf(output, "#define ANTLR_VERSION	%s\n", VersionDef);};
	if ( strcmp(ParserName, "zzparser")!=0 )
		{fprintf(output, "#define %s %s\n", "zzparser", ParserName);};
   	if ( strcmp(ParserName, "zzparser")!=0 )
		{{fprintf(output, "#include \"%s\"\n", RemapFileName);};}
	if ( GenLineInfo ) {fprintf(output, "# %d \"%s\"\n", 1, FileStr[file]);};
	if ( GenCC ) {
		if ( UserTokenDefsFile != 0 )
			fprintf(output, "#include %s\n", UserTokenDefsFile);
		else
			fprintf(output, "#include \"%s\"\n", DefFileName);
	}

	if ( HdrAction != 0 ) dumpAction( HdrAction, output, 0, -1, 0, 1);
	if ( !GenCC && FoundGuessBlk )
	{
		{fprintf(output, "#define ZZCAN_GUESS\n");};
		{fprintf(output, "#include <setjmp.h>\n");};
	}
	if ( FoundException )
	{
		{fprintf(output, "#define EXCEPTION_HANDLING\n");};
		{fprintf(output, "#define NUM_SIGNALS %d\n", NumSignals);};
	}
	if ( !GenCC && OutputLL_k > 1 ) {fprintf(output, "#define LL_K %d\n", OutputLL_k);};
	if ( GenAST&&!GenCC ) {fprintf(output, "#define GENAST\n\n");};
	if ( GenAST ) {
		if ( GenCC ) {{fprintf(output, "#include \"%s\"\n\n", "ASTBase.h");};}
		else {fprintf(output, "#include \"ast.h\"\n\n");};
	}
	if ( !GenCC && DemandLookahead ) {fprintf(output, "#define DEMAND_LOOK\n\n");};
# 2085 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

	
	if ( !GenCC ) {fprintf(output, "#define zzSET_SIZE %d\n", ((((unsigned)(TokenNum-1))>>((sizeof(unsigned)*8)==16?4:5))+1)*sizeof(unsigned));};
	if ( !GenCC ) {{fprintf(output, "#include \"antlr.h\"\n");};}
	else {
		{fprintf(output, "#include \"%s\"\n", "AParser.h");};
		{fprintf(output, "#include \"%s.h\"\n", CurrentClassName);};
	}
	if ( !GenCC ) {
		if ( UserDefdTokens )
			{{fprintf(output, "#include %s\n", UserTokenDefsFile);};}
		
		{fprintf(output, "#include \"%s\"\n", DefFileName);};
	}
	
	if ( !GenCC ) {fprintf(output, "#include \"dlgdef.h\"\n");};
	if ( LexGen && GenCC ) {fprintf(output, "#include \"%s\"\n", "DLexerBase.h");};
	if ( !GenCC && LexGen ) {fprintf(output, "#include \"%s\"\n", ModeFileName);};
}

void

genHdr1( int file )
# 2111 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	ListNode *p;

	genHdr(file);
	if ( GenAST )
	{
		if ( !GenCC ) {
			{fprintf(output, "#include \"ast.c\"\n");};
			{fprintf(output, "zzASTgvars\n\n");};
		}
	}
	if ( !GenCC ) {fprintf(output, "ANTLR_INFO\n");};
	if ( BeforeActions != 0 )
	{
		for (p = BeforeActions->next; p!=0; p=p->next)
		{
			UserAction *ua = (UserAction *)p->elem;
			dumpAction( ua->action, output, 0, ua->file, ua->line, 1);
		}
	}

	if ( !FoundException ) return;

	if ( GenCC )
	{
		{fprintf(output, "\nvoid %s::\n", CurrentClassName);};
		{fprintf(output, "zzdflthandlers( int _signal, int *_retsignal )\n");};
		{fprintf(output, "{\n");};
	}
	else
	{
		{fprintf(output, "\nvoid\n");};
		{fprintf(output, "#ifdef __STDC__\n");};
		{fprintf(output, "zzdflthandlers( int _signal, int *_retsignal )\n");};
		{fprintf(output, "#else\n");};
		{fprintf(output, "zzdflthandlers( _signal, _retsignal )\n");};
		{fprintf(output, "int _signal;\n");};
		{fprintf(output, "int *_retsignal;\n");};
		{fprintf(output, "#endif\n");};
		{fprintf(output, "{\n");};
	}
	tabs++;
	{tab(); fprintf(output, "*_retsignal = _signal;\n");};
	if ( DefaultExGroup!=0 )
	{
		dumpException(DefaultExGroup, 1);
		if ( !hasDefaultException(DefaultExGroup) )
		{
			{tab(); fprintf(output, "default :\n");};
			tabs++;
			{tab(); fprintf(output, "*_retsignal = _signal;\n");};
			tabs--;
			{tab(); fprintf(output, "}\n");};
		}
	}

	tabs--;
	{fprintf(output, "}\n\n");};
}

void

genStdPCCTSIncludeFile( struct _iobuf *f )
# 2178 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	fprintf(f,"#ifndef STDPCCTS_H\n");
	fprintf(f,"#define STDPCCTS_H\n");
	fprintf(f,"/*\n");
	fprintf(f," * %s -- P C C T S  I n c l u d e\n", stdpccts);
	fprintf(f," *\n");
	fprintf(f," * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994\n");
	fprintf(f," * Purdue University Electrical Engineering\n");
	fprintf(f," * With AHPCRC, University of Minnesota\n");
	fprintf(f," * ANTLR Version %s\n", Version);
	fprintf(f," */\n");
	fprintf(f,"#include <stdio.h>\n");
	fprintf(f,"#define ANTLR_VERSION	%s\n", VersionDef);
	if ( GenCC )
	{
		if ( UserDefdTokens )
			fprintf(f, "#include %s\n", UserTokenDefsFile);
		else {
			fprintf(f, "#include \"%s\"\n", DefFileName);
		}

		fprintf(f, "#include \"%s\"\n", "AToken.h");

		if ( HdrAction != 0 ) dumpAction( HdrAction, f, 0, -1, 0, 1);

		fprintf(f, "#include \"%s\"\n", "ATokenBuffer.h");

		if ( OutputLL_k > 1 ) fprintf(f,"static const unsigned LL_K=%d;\n", OutputLL_k);
		if ( GenAST ) {
			fprintf(f, "#include \"%s\"\n", "ASTBase.h");
		}
		fprintf(f,"#include \"%s\"\n", "AParser.h");
		fprintf(f,"#include \"%s.h\"\n", CurrentClassName);
		if ( LexGen ) fprintf(f,"#include \"%s\"\n", "DLexerBase.h");
		fprintf(f, "#endif\n");
		return;
	}

	if ( strcmp(ParserName, "zzparser")!=0 )
		fprintf(f, "#define %s %s\n", "zzparser", ParserName);
	if ( strcmp(ParserName, "zzparser")!=0 )
		fprintf(f, "#include \"%s\"\n", RemapFileName);
	if ( UserTokenDefsFile != 0 )
	   fprintf(f, "#include %s\n", UserTokenDefsFile);
	if ( HdrAction != 0 ) dumpAction( HdrAction, f, 0, -1, 0, 1);
	if ( FoundGuessBlk )
	{
		fprintf(f,"#define ZZCAN_GUESS\n");
		fprintf(f,"#include <setjmp.h>\n");
	}
	if ( OutputLL_k > 1 ) fprintf(f,"#define LL_K %d\n", OutputLL_k);
	if ( GenAST ) fprintf(f,"#define GENAST\n");
	if ( FoundException )
	{
		{fprintf(output, "#define EXCEPTION_HANDLING\n");};
		{fprintf(output, "#define NUM_SIGNALS %d\n", NumSignals);};
	}
	if ( DemandLookahead ) fprintf(f,"#define DEMAND_LOOK\n");
# 2239 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

	
	fprintf(f, "#define zzSET_SIZE %d\n", ((((unsigned)(TokenNum-1))>>((sizeof(unsigned)*8)==16?4:5))+1)*sizeof(unsigned));
	fprintf(f,"#include \"antlr.h\"\n");
	if ( GenAST ) fprintf(f,"#include \"ast.h\"\n");
	if ( UserDefdTokens )
		fprintf(f, "#include %s\n", UserTokenDefsFile);
	
	fprintf(f, "#include \"%s\"\n", DefFileName);
	
	fprintf(f,"#include \"dlgdef.h\"\n");
	
	if ( LexGen ) fprintf(f,"#include \"%s\"\n", ModeFileName);
	fprintf(f,"#endif\n");
}










void

dumpAction( char *s, struct _iobuf *output, int tabs, int file, int line,  
int final_newline )
# 2276 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
    int inDQuote, inSQuote;
    {if ( !(s!=0) ) fatal_intern( 		"dumpAction: NULL action", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2279);};
    {if ( !(output!=0) ) fatal_intern(	eMsg3("dumpAction: output FILE is NULL for %s",s,0,0), "/circle/s13/parrt/PCCTS/antlr/gen.c", 2280);};

	if ( GenLineInfo && file != -1 )
	{
		fprintf(output, "# %d \"%s\"\n", line, FileStr[file]);
	}
    while (*( s ) == ' ' || *( s ) == '\t') { s ++;};
	
	if ( *s!='#' ) {{ int i; for (i=0; i<tabs; i++) fputc('\t', output); };}
    inDQuote = inSQuote = 0;
    while ( *s != '\0' )
    {
        if ( *s == '\\' )
        {
            fputc( *s++, output ); 
            if ( *s == '\0' ) return;
            if ( *s == '\'' ) fputc( *s++, output );
            if ( *s == '\"' ) fputc( *s++, output );
        }
        if ( *s == '\'' )
        {
            if ( !inDQuote ) inSQuote = !inSQuote;
        }
        if ( *s == '"' )
        {
            if ( !inSQuote ) inDQuote = !inDQuote;
        }
        if ( *s == '\n' )
        {
            fputc('\n', output);
			s++;
            while (*( s ) == ' ' || *( s ) == '\t') { s ++;};
            if ( *s == '}' )
            {
                --tabs;
				{ int i; for (i=0; i<tabs; i++) fputc('\t', output); };
                fputc( *s++, output );
                continue;
            }
            if ( *s == '\0' ) return;
			if ( *s != '#' )	
            {
				{ int i; for (i=0; i<tabs; i++) fputc('\t', output); };
			}
        }
        if ( *s == '}' && !(inSQuote || inDQuote) )
        {
            --tabs;            
        }
        if ( *s == '{' && !(inSQuote || inDQuote) )
        {
            tabs++;            
        }
        fputc( *s, output );
        s++;
    }
    if ( final_newline ) fputc('\n', output);
}

static void

dumpAfterActions( struct _iobuf *output )
# 2345 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	ListNode *p;
	{if ( !(output!=0) ) fatal_intern( "dumpAfterActions: output file was NULL for some reason", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2348);};
	if ( AfterActions != 0 )
	{
		for (p = AfterActions->next; p!=0; p=p->next)
		{
			UserAction *ua = (UserAction *)p->elem;
			dumpAction( ua->action, output, 0, ua->file, ua->line, 1);
		}
	}
	fclose( output );
}










static ActionNode *

findImmedAction( Node *q )
# 2375 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	Junction *j;
	{if ( !(q!=0) ) fatal_intern( "findImmedAction: NULL node", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2378);};
	{if ( !(q->ntype>=1 && q->ntype<=4) ) fatal_intern( "findImmedAction: invalid node", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2379);};
	
	while ( q->ntype == 1 )
	{
		j = (Junction *)q;
		if ( j->jtype != 6 || j->p2 != 0 ) return 0;
		q = j->p1;
		if ( q == 0 ) return 0;
	}
	if ( q->ntype == 4 ) return (ActionNode *)q;
	return 0;
}

static void

dumpRetValAssign( char *retval, char *ret_def )
# 2399 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	char *q = ret_def;
	
	tab();
	while ( *retval != '\0' )
	{
		while ( ((_ctype_+1)[(*retval)]&010) ) retval++;
		while ( *retval!=',' && *retval!='\0' ) fputc(*retval++, output);
		fprintf(output, " = _trv.");
		
		DumpNextNameInDef(&q, output);
		fputc(';', output); fputc(' ', output);
		if ( *retval == ',' ) retval++;
	}
}




static set

ComputeErrorSet( Junction *j, int k )
# 2426 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	Junction *alt1;
	set a, rk, f;
	{if ( !(j->ntype==1) ) fatal_intern( "ComputeErrorSet: non junction passed", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2430);};

	f = rk = empty;
	for (alt1=j; alt1!=0; alt1 = (Junction *)alt1->p2)
	{
		{if ( (alt1->p1)==0 ) fatalFL("REACH: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2435); ( a) = (*(fpReach[(alt1->p1)->ntype]))( alt1->p1,  k,  &rk );};
		{if ( !(set_nil(rk)) ) fatal_intern( "ComputeErrorSet: rk != nil", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2436);};
		{if ( (rk).setword != 0 ) free((char *)((rk).setword)); (rk) = empty;};
		set_orin(&f, a);
		{if ( (a).setword != 0 ) free((char *)((a).setword)); (a) = empty;};
	}
	return f;
}

static char *

tokenFollowSet(TokNode *p)
# 2450 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
    static char buf[100];
    set rk, a;
    int n;
    rk = empty;

    {if ( (p->next)==0 ) fatalFL("REACH: NULL object", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2457); ( a) = (*(fpReach[(p->next)->ntype]))( p->next,  1,  &rk );};
    {if ( !(set_nil(rk)) ) fatal_intern( "rk != nil", "/circle/s13/parrt/PCCTS/antlr/gen.c", 2458);};
    {if ( (rk).setword != 0 ) free((char *)((rk).setword)); (rk) = empty;};
    n = DefErrSet( &a, 0, 0 );
    {if ( (a).setword != 0 ) free((char *)((a).setword)); (a) = empty;};
    if ( GenCC )
        sprintf(buf, "err%d", n);
    else
        sprintf(buf, "zzerr%d", n);
    return buf;
}

static void

makeErrorClause( Junction *q, set f, int max_k )
# 2477 "/circle/s13/parrt/PCCTS/antlr/gen.c" 

{
	if ( FoundException )
	{
		{fprintf(output, "else {\n");};
		tabs++;
		if ( FoundGuessBlk )
		{
			if ( GenCC ) {{tab(); fprintf(output, "if ( guessing ) goto fail;\n");};}
			else {tab(); fprintf(output, "if ( zzguessing ) goto fail;\n");};
		}
		{tab(); fprintf(output, "if (_sva) _signal=NoViableAlt;\n");};
		{tab(); fprintf(output, "else _signal=NoSemViableAlt;\n");};
		{tab(); fprintf(output, "goto _handler;\n");};
		tabs--;
		{tab(); fprintf(output, "}\n");};
		return;
	}

	if ( max_k == 1 )
	{
		if ( GenCC ) {{fprintf(output, "else {FAIL(1,err%d", DefErrSet(&f,1,0));};}
		else {fprintf(output, "else {zzFAIL(1,zzerr%d", DefErrSet(&f,1,0));}
		{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
	}
	else
	{
		int i;
		{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
		if ( GenCC ) {{fprintf(output, "else {FAIL(%d", max_k);};}
		else {fprintf(output, "else {zzFAIL(%d", max_k);};
		for (i=1; i<=max_k; i++)
		{
			f = ComputeErrorSet(q, i);
			if ( GenCC ) {{fprintf(output, ",err%d", DefErrSet( &f, 1, 0 ));};}
			else {fprintf(output, ",zzerr%d", DefErrSet( &f, 1, 0 ));};
			
			{if ( (f).setword != 0 ) free((char *)((f).setword)); (f) = empty;};
		}
	}
	{fprintf(output, ",&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}\n");};
}
