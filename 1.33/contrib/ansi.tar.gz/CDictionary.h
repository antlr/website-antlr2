#ifndef CDictionary_h
#define CDictionary_h

#include "DictEntry.h"
#include "Dictionary.h"
#include "CSymbol.h"

class CDictionary : public Dictionary {
protected:
	void dumpSymbol(FILE *f, DictEntry *de)
		{
			CSymbol *cs = (CSymbol *)de;
			if ( !(cs->getType()&CSymbol::otType) ) fprintf(f, "[non-");
			else fprintf(f, "[");
			fprintf(f, "type: %s]\n", cs->getKey());
		}
public:
	CDictionary(int nb=43, int ns=50, int nc=30000)
		: Dictionary(nb, ns, nc) {;}
};

#endif
