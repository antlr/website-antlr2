#ifndef DictEntry_h
#define DictEntry_h

class DictEntry {
protected:
	char *key;
	int hashCode;
	DictEntry *next;		// next element in the bucket
	DictEntry *scope;		// next element in the scope
public:
	DictEntry()				{ key=NULL; next=scope=NULL; hashCode = -1; }
	~DictEntry()			{ key=NULL; next=scope=NULL; hashCode = -1; }
	DictEntry(char *k, int h=-1) { key=k; hashCode = h; next=scope=NULL; }

	char *getKey()			{ return key; }
	void setKey(char *k)	{ key = k; }

	int getHashCode()		{ return hashCode; }
	void setHashCode(int h)	{ hashCode = h; }

	void setNext(DictEntry *n)	{ next = n; }
	DictEntry *getNext()		{ return next; }

	void setScope(DictEntry *s)	{ scope = s; }
	DictEntry *getNextInScope()	{ return scope; }
};

#endif
