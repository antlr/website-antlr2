#include <stream.h>
#include "tokens.h"
#include "CParser.h"
typedef ANTLRCommonToken ANTLRToken;
#include "CSymbol.h"

int CParser::
isTypeName(char *s)
{
	CSymbol *cs = (CSymbol *) symbols->lookup(s);
	if ( cs==NULL || cs->getType()!=CSymbol::otType ) return 0;
	return 1;
}

void CParser::
beginDeclaration()
{
}

void CParser::
endDeclaration()
{
}

void CParser::
beginFunctionDefinition()
{
	functionDefinition = 1;
}

void CParser::
endFunctionDefinition()
{
	fprintf(stderr, "parameter scope:\n");
	symbols->dumpScope(stderr);
	symbols->removeScope();
	symbols->restoreScope();
	functionDefinition = 0;
}

void CParser::
beginParameterDeclaration()
{
}

void CParser::
beginFieldDeclaration()
{
}

void CParser::
declarationSpecifier(StorageClass sc,
					 TypeQualifier tq,
					 TypeSpecifier ts)
{
	_sc = sc;
	_tq = tq;
	_ts = ts;
}

void CParser::
declaratorPointerTo()
{
}

/* Symbols from declarators are added to the symbol table here.  Note
 * that we only care about types for parsing (with semantic predicates)
 * and we don't track variable vs function.  A real C front-end would
 * have to, of course.  The symbol is added to whatever the current
 * scope is in the symbol table.
 */
void CParser::
declaratorID(char *id)
{
	CSymbol *c;
	if ( _sc==scTYPEDEF ) c = new CSymbol(id, CSymbol::otType);
	else c = new CSymbol(id);
	if ( c==NULL ) panic("can't alloc CSymbol");
	symbols->define(id, c);
}

void CParser::
declaratorArray()
{
}

void CParser::
declaratorParameterList()
{
	symbols->saveScope();
}

void CParser::
declaratorEndParameterList()
{
	if ( !functionDefinition ) {
		fprintf(stderr, "parameter scope:\n");
		symbols->dumpScope(stderr);
		symbols->removeScope();
		symbols->restoreScope();
	}
}

void CParser::
enterNewLocalScope()
{
	symbols->saveScope();
}

void CParser::
exitLocalScope()
{
	fprintf(stderr, "local scope:\n");
	symbols->dumpScope(stderr);
	symbols->removeScope();
	symbols->restoreScope();
}

void CParser::
enterExternalScope()
{
}

void CParser::
exitExternalScope()
{
	fprintf(stderr, "global scope:\n");
	symbols->dumpScope(stderr);
	symbols->removeScope();
}

void CParser::
beginAggrDefinition(TypeSpecifier ts, char *tag)
{
	CSymbol *c;

	if ( ts==tsSTRUCT ) c = new CSymbol(tag, CSymbol::otStruct);
	else c = new CSymbol(tag, CSymbol::otUnion);
	if ( c==NULL ) panic("can't alloc CSymbol");
	symbols->define(tag, c);

	symbols->saveScope();	// use the scope to collect list of fields
}

void CParser::
endAggrDefinition()
{
	fprintf(stderr, "list of fields:\n");
	symbols->dumpScope(stderr);
	symbols->removeScope();
	symbols->restoreScope();
}

void CParser::
panic(char *err)
{
	fprintf(stderr, "CParser: %s\n", err);
	exit(-1);
}

void CParser::
tracein(char *r)
{
	if ( !doTracing ) return;
	for (int i=1; i<=traceIndentLevel; i++) fprintf(stderr, " ");
	traceIndentLevel++;
	fprintf(stderr, "enter %s('%s %s')%s\n",
			r,
			LT(1)->getText(),
			LT(2)->getText(),
			guessing?" [guessing]":"");
}

void CParser::
traceout(char *r)
{
	if ( !doTracing ) return;
	traceIndentLevel--;
	for (int i=1; i<=traceIndentLevel; i++) fprintf(stderr, " ");
	fprintf(stderr, "exit %s%s\n", r, guessing?" [guessing]":"");
}
