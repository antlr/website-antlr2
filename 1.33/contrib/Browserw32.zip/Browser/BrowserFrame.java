import java.awt.*;

public class BrowserFrame extends Frame {

    public BrowserFrame() {

        super("BrowserFrame window");

        //{{INIT_CONTROLS
        setLayout(null);
        addNotify();
        resize(insets().left + insets().right + 509, insets().top + insets().bottom + 474);
        tagList=new List();
        add(tagList);
        tagList.reshape(insets().left + 17,insets().top + 16,277,107);
        codeDisplayPane=new TextArea();
        codeDisplayPane.setFont(new Font("Courier",Font.BOLD,10));
        add(codeDisplayPane);
        codeDisplayPane.reshape(insets().left + 14,insets().top + 137,476,299);
        //}}

        //{{INIT_MENUS
        MenuBar mb = new MenuBar();
        fileMenu = new Menu("File");
        fileMenu.add(new MenuItem("Open..."));
        fileMenu.addSeparator();
        fileMenu.add(new MenuItem("Quit"));
        mb.add(fileMenu);
        setMenuBar(mb);
        //}}
    }

    public synchronized void show() {
    	move(50, 50);
    	super.show();
    }

    public boolean handleEvent(Event event) {

    	if (event.id == Event.WINDOW_DESTROY) {
    	    hide();
			System.exit(1);
    	    return true;
    	}
    	return super.handleEvent(event);
    }

    //{{DECLARE_MENUS
    Menu fileMenu;
    //}}

    //{{DECLARE_CONTROLS
    List tagList;
    TextArea codeDisplayPane;
    //}}
    public void selectedOpen() {
        // to do: put event handler code here.
    }

    public boolean action(Event event, Object arg) {
    if (event.target instanceof MenuItem) {
        String label = (String) arg;
        if (label.equalsIgnoreCase("Quit")) {
            selectedQuit();
            return true;
        } else if (label.equalsIgnoreCase("Open...")) {
            selectedOpen();
            return true;
        } 
    }
        return super.action(event, arg);
    }
    public void selectedQuit() {
        // to do: put event handler code here.
    }
}


