import java.io.*;
import java.awt.Event;
import java.awt.List;
import java.util.Vector;
import java.awt.FileDialog;

public class TagBrowserFrame extends BrowserFrame {
	private Vector lineIndex;	// map line # to char number in text area
	private String fileName;
	private TagTreeRoot tags;	// a reference to the "model"
	private Browser browser;

	public TagBrowserFrame(String fileName, Browser browser) {
		setTitle("Browsing "+fileName);
		this.fileName = fileName;
		codeDisplayPane.setEditable(false);
		this.browser = browser;
	}

	public void setFileName(String f) {
		setTitle("Browsing "+f);
		fileName = f;
	}
	
	public void setTags(TagTreeRoot tags) {
		this.tags = tags;
		lineIndex = new Vector(5);  // 1..ntags
		tagList.clear();
		codeDisplayPane.setText("");
	}
	
	public void addTag(String id) {
		tagList.addItem(id);
	}

	public void displayFile() {
		int c = 0;		// character number in view text area
		int ln = 1;		// which line are we on?

		try {
			FileInputStream f = new FileInputStream(fileName);
			DataInputStream in = new DataInputStream(f);
			String line = in.readLine();
			while ( line!=null ) {
				// record the char index for line number ln
				lineIndex.setSize(ln+1);
				lineIndex.setElementAt(new Integer(c), ln);
				ln++;
				c+=line.length()+1;	// include \n
				codeDisplayPane.appendText(line+"\n");
				line = in.readLine();
			}
			in.close();
		}
		catch (Exception io) {
			System.err.println(io.getMessage());
			io.printStackTrace();
		}
	}

	public void selectLine(int n) {
		codeDisplayPane.insertText("",
			((Integer)lineIndex.elementAt(n)).intValue());
		codeDisplayPane.requestFocus();
	}

	public boolean action(Event e, Object arg) {
		if ( e.target == tagList ) {
			int n = ((List)e.target).getSelectedIndex();
			selectLine(tags.lineCache[n]);
			return true;
		}
		return super.action(e,arg);
	}

    public void selectedOpen() {
        FileDialog fd = new FileDialog(this, "Open File To Browse");
		fd.show();
		System.out.println("open file "+fd.getFile());
		browser.loadFile(fd.getFile());
    }

    public void selectedQuit() {
        System.exit(0);
    }
}
