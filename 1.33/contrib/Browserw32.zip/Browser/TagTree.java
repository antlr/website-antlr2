import java.io.*;
import java.util.StringTokenizer;

public class TagTree {
	protected String id;
	protected int line;			// what line in the source code is id defined?

	private TagTree next;		// next tag in this list (set by parent node)
	private TagTree children;	// list of members if class or locals if method
	private TagTree lastChild;	// ptr to last child element

	public TagTree(String id) {
		this.id = id;
		next = children = lastChild = null;
	}

	public TagTree(String id, int line) {
		this(id);
		this.line = line;
	}

	/** Add a tag as a child and sort according to id */
	public void addChild(TagTree t) {
		if ( children == null ) {
			children = lastChild = t;
		}
		else {
			// do insertion sort
			TagTree search = children;
			TagTree prev = null;
			while ( search!=null && search.id.compareTo(t.id) <= 0 ) {
				prev = search;
				search = search.next;
			}
			if ( search == null ) {
				// put on end of list
				lastChild.next = t;
				lastChild = t;
			}
			else if ( prev == null ) {
				// insert at head
				t.next = children;
				children = t;
			}
			else {
				// insert in middle somewhere
				t.next = search;
				prev.next = t;
			}
		}
	}

	
	public TagTree getChildren() {
		return children;
	}
	
	/**Walk entire tree, adding tags to the view ListBox.
	 * As view is updated, flatten tree into a linear list
	 * for easy event handling.
	 * Record array of line numbers (maps tag list element to line #).
	 */
	public void updateView(TagBrowserFrame bframe, TagTreeRoot root) {
		int[] lines;
		TagTree t = this;
		if ( root.lineCache==null ) {
			root.lineCache = new int[root.ntags];
		}
		while ( t!=null ) {
			bframe.addTag(t.id);
			root.lineCache[root.i] = t.line;
			root.i++;
			if ( t.children!=null ) {
				t.children.updateView(bframe, root);
			}
			t = t.next;
		}
	}

	public static TagTreeRoot readInTags(String tagFile) {
		TagTreeRoot classList = new TagTreeRoot();
		TagTree currentClass = null;
		TagTree currentMethod = null;
		int n = 0;

		try {
			FileInputStream f = new FileInputStream(tagFile);
			DataInputStream in = new DataInputStream(f);
			String line = in.readLine();

			while ( line!=null ) {
				StringTokenizer tokenizer = new StringTokenizer(line, " ");
				String type = tokenizer.nextToken();
				if ( type.equals("class") ) {
					// "class $id $line"
					String className = tokenizer.nextToken();
					int ln = Integer.parseInt(tokenizer.nextToken());
					TagTree classNode = new TagTree(className, ln);
					currentClass = classNode;
					classList.addChild(classNode);
					n++;
				}
				else if ( type.equals("method") ) {
					// "method $className $id $line"
					String className = tokenizer.nextToken();
					String id = tokenizer.nextToken();
					int ln = Integer.parseInt(tokenizer.nextToken());
					currentMethod = new TagTree(className+"."+id, ln);
					currentClass.addChild(currentMethod);
					n++;
				}
				else if ( type.equals("local") ) {
					// "local $className $methodName $id $scope $line"
					String className = tokenizer.nextToken();
					String methodName = tokenizer.nextToken();
					String id = tokenizer.nextToken();
					String scope = tokenizer.nextToken();
					int ln = Integer.parseInt(tokenizer.nextToken());
					currentMethod.addChild(
						new TagTree(className+"."+methodName+":"+id+","+scope, ln)
						);
					n++;
				}
				else if ( type.equals("variable") ) {
					// "local $className $id $line"
					String className = tokenizer.nextToken();
					String id = tokenizer.nextToken();
					int ln = Integer.parseInt(tokenizer.nextToken());
					currentClass.addChild(new TagTree(className+"."+id, ln));
					n++;
				}
				line = in.readLine();
			}

			in.close();
		}
		catch (Exception io) {
			System.err.println(io.getMessage());
			io.printStackTrace();
		}

		classList.ntags = n;
		return classList;
	}

	public String toString() {
		String s = "( ";
		TagTree t = this;
		int n=0;
		while ( t!=null ) {
			s += " "+t.id;
			n++;
			if ( t.children!=null ) {
				s += t.children.toString();
			}
			t = t.next;
		}
		return s+")";
	}

}
