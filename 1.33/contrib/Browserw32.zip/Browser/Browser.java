import java.io.*;
import java.awt.*;
import java.util.StringTokenizer;

public class Browser {
	TagBrowserFrame bframe;	// the "view"
	TagTree tags;			// the "model"

	public Browser(String f) {
		this();
		loadFile(f);
		/*
		//AnInteger ntags = new AnInteger();
		TagTreeRoot tags = TagTree.readInTags(tagFile);
		bframe = new TagBrowserFrame(f, this);
		bframe.show();
		bframe.setTags(tags);
		tags.getChildren().updateView(bframe, tags);
		bframe.displayFile();
		bframe.selectLine(1);
		*/
	}

	public Browser() {
		bframe = new TagBrowserFrame("no file", this);
		bframe.show();
	}

	public void loadFile(String f) {
		//System.out.println("execing 'parser/javap -in "+f+" -out tags.tmp'");
		runParser(f, "tags.tmp");
		//System.out.println("back from execing 'parser/javap -in "+f+" -out tags.tmp'");
		TagTreeRoot tags = TagTree.readInTags("tags.tmp");
		bframe.setTags(tags);
		tags.getChildren().updateView(bframe, tags);
		bframe.setFileName(f);
		bframe.displayFile();
		bframe.selectLine(1);
	}

	public void runParser(String javaFile, String tagFile) {
		Runtime rt = Runtime.getRuntime();
		Process p = null;
		try {
			p = rt.exec("parser/javap -in "+javaFile+" -out "+tagFile);
			p.waitFor();
		} catch (IOException e) {
			System.err.println("could not exec java parser");
		} catch (InterruptedException e) {
			System.err.println("java parser interrupted");
		}
	}
	
	public static void main(String[] args) {
		if ( args.length == 1 ) {
			new Browser(args[0]);
		}
		else {
			new Browser();
		}
	}
}
