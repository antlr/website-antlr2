public class TagTreeRoot extends TagTree {
	public int ntags;
	public int lineCache[];
	public int i;				// used to add elements

	public TagTreeRoot() {
		super("<root>");
	}
}
