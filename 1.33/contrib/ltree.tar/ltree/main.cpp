/*
 * main.c -- main program for ltree.
 *
 * RIGHTS
 * 
 * Parr Research Corporation maintains the copyright on this software,
 * but any individual or company may use LTREE free of charge.  LTREE may
 * not be incorporated into commercial software or for commercial gain
 * without permission from Parr Research Corporation, but the postscript
 * output may be used for any purpose.  The source for LTREE may be
 * freely distributed as long as the headers and this README are
 * distributed along with the software and the files remain unmodified.
 * 
 * LTREE uses PCCTS, which is public-domain software developed by Parr
 * Research Corporation--some PCCTS files have been included.
 * 
 * WARRANTY
 * 
 * Parr Research Corporation makes no claims that this software does
 * anything useful, that it works, or even that it compiles.  "Your
 * mileage may vary."
 * 
 * Terence Parr
 * Parr Research Corporation
 * September 1995
 */
#include <iostream.h>
#include "adobe.h"
#include <math.h>
#include <strings.h>
#include "ltree.h"

void dimensions(AST *, int);
void dimensions_main(AST *, int);
void dimensions_of_siblings(AST *, AST *, int widest, int *max_h, int *w);
void dump_PS(AST *, int, int, int);
void dump_PS_header(AST *);
int height(AST *);
int widest_in_column(AST *);
int atom_pt_width(AST *);

static int ux=0, uy=0;

int PT_SIZE = 10;			/* we assume Courier (const width) */

int genPS(AST *, int x, int y, int widest );

main(int argc, char *argv[])
{
	if ( argc==3 ) {
		if ( strcmp(argv[1],"-fs")==0 ) {
			PT_SIZE = atoi(argv[2]);
		}
	}

	ParserBlackBox<DLGLexer, LTREEParser, ANTLRToken> p(stdin);
	AST *root = NULL;
	p.parser()->item((ASTBase **)&root);
	if ( root==NULL ) return 0;

	dimensions_main(root, widest_in_column(root));
//	root->dim().display();
	dump_PS_header(root);
	dump_PS(root,
			0,
			height(root)-ATOM_HEIGHT + TREE_BOX_PADDING/2,
			widest_in_column(root));
	printf("showpage\n");
	printf("%%%%Trailer\n");
	printf("%%%%BoundingBox: %d %d %d %d\n", 0,0,
		   ux+TREE_BOX_PADDING,
		   uy+TREE_BOX_PADDING);

	return 0;
}

/* walk straight down the ->down pointers to find the largest atom width in pts */
int
widest_in_column(AST *t)
{
	int max=0;

	while (t!=NULL)
	{
		if ( atom_pt_width(t) > max ) max = atom_pt_width(t);
		t = (AST *)t->down();
	}
	return max;
}

/* ignore \i change font directive */
Tuple
atom_pt_size(AST *t)
{
	int ignore=0;

	if ( strncmp(t->getText(), "\\i ", 3)==0 ) ignore += 3;
	return Tuple((strlen(t->getText())-ignore)*TEXT_CHAR_WIDTH, ATOM_HEIGHT);
}

int
atom_pt_width(AST *t)
{
	int ignore=0;

	if ( strncmp(t->getText(), "\\i ", 3)==0 ) ignore += 3;
	return (strlen(t->getText())-ignore)*TEXT_CHAR_WIDTH;
}

inline int
max(int a, int b)
{
	return a>b ? a : b;
}

int
height(AST *t)
{
	int h=0;

	for (; t!=NULL; t=(AST *)t->right())
	{
		if ( t->dim().y() > h ) h = t->dim().y();
	}
	return h;
}

void
dimensions_main(AST *p, int widest)
{
	if ( p->right() != NULL )
	{
		int d1,d2;
		dimensions_of_siblings(p, NULL, widest, &d1, &d2);
	}
	else
	{
		dimensions(p, widest);
	}
}

void
dimensions_of_siblings(AST *p, AST *parent, int widest, int *max_h, int *w)
{
	AST *t;

	for (t=p; t!=NULL; t=(AST *)t->right())
	{
		/* if 1st sibling, use parent's widest computation */
		if ( parent!=NULL && t==parent->down() )
		{
			dimensions(t, widest);
			*w += max(widest, t->dim().x());
		}
		else
		{
			dimensions(t, widest_in_column(t));
			*w += t->dim().x();
		}
		if ( t->right()!=NULL )
		{
			if ( t==p->down() && t->dim().x() < widest ) *w += HORIZ_LINE_WIDTH+PADDING;
			else *w += HORIZ_LINE_WIDTH+(2*PADDING);
		}
		if ( t->dim().y() > *max_h ) *max_h = t->dim().y();
	}
}

/* The dimension of an atom is just the width/height of the text.
 * The dimension of an atom that is also a subtree root is the
 * dimension of entire subtree BELOW it including itself.
 * Note: the width of a sibling list is also a function of the widest element
 * 	in the column of the first sibling.  I.e., the parent of the sibling list
 * 	can be wider than what is below and then things will get too packed in the
 * 	horizontal plane.  Hence, we passed a 'widest' variable just like
 *	when dumping PS.
 */
void
dimensions(AST *p, int widest)
{
	AST *t=p;
	int w=0, max_h=0;

	if ( t==NULL ) return;
	if ( t->down() == NULL ) {t->dim(atom_pt_size(t)); return;}

	dimensions_of_siblings((AST *)t->down(), t, widest, &max_h, &w);

	p->dim().x( max(w,atom_pt_width(p)) );
	p->dim().y( VERT_LINE_HEIGHT+(2*PADDING)+ATOM_HEIGHT+max_h );
}

void
dump_PS_header(AST *t)
{
	FM_REQD_HEADER;
	printf("%%%%BoundingBox: (atend)\n");
	printf("%%%%DocumentFonts: Courier\n");
	printf("%%%%EndComments\n");

	THINLINES;
	printf("%%\n");
	printf("%% x y rarrow\n");
	printf("%%\n");
	printf("/rarrow {\n");
	printf("moveto\n");
	printf("-3 +2 rlineto\n");
	printf("0 -4 rlineto\n");
	printf("3 +2 rlineto\n");
	printf("fill\n");
	printf("} def\n");
	printf("%%\n");
	printf("%% x y darrow\n");
	printf("%%\n");
	printf("/darrow {\n");
	printf("moveto\n");
	printf("-2 +3 rlineto\n");
	printf("4 0 rlineto\n");
	printf("-2 -3 rlineto\n");
	printf("fill\n");
	printf("} def\n");
	COURIER(PT_SIZE);
}

/*
 * Move to the top left of the box surrounding the tree (minus height of atom)
 * Print out 't'
 * Print out what lives beneath 't'
 * Print out what lives to the right of 't'
 * Draw line from 't' to 't->down'
 * Draw line from 't' to 't->right'
 *
 * A starting offset is specified.
 *
 * Font change to italics is done via "\i atom"
 */
void
dump_PS(AST *t, int x, int y, int widest)
{
	int x_old, fudge_factor;

	for (; t!=NULL; t=(AST *)t->right())
	{
		if ( strncmp(t->getText(), "\\i ", 3)==0 )
		{
			ITALICS(PT_SIZE+1);
			TEXT(&(t->getText()[3]), x+widest/2-atom_pt_width(t)/2, y);
			COURIER(PT_SIZE);
			/* set bounding box */
			if ( (x+widest) > ux ) ux = x+widest;
			if ( (y+TEXT_CHAR_HEIGHT) > uy ) uy = y+TEXT_CHAR_HEIGHT;
		}
		else TEXT(t->getText(), x+widest/2-atom_pt_width(t)/2, y);

		/* set bounding box */
		if ( (x+widest) > ux ) ux = x+widest;
		if ( (y+TEXT_CHAR_HEIGHT) > uy ) uy = y+TEXT_CHAR_HEIGHT;

		if ( t->down() != NULL )
		{
			MOVE(x+widest/2,y-PADDING);
			LINE(x+widest/2,y-(VERT_LINE_HEIGHT+PADDING));
			STROKE;
			DARROW(x+widest/2,y-(VERT_LINE_HEIGHT+PADDING));
			dump_PS((AST *)t->down(), x, y-(ATOM_HEIGHT+VERT_LINE_HEIGHT+(2*PADDING)), widest);
		}
		x_old = x;

		x += max(t->dim().x(),widest) + HORIZ_LINE_WIDTH + PADDING;

		/* don't move over too far if this item is skinnier than widest in column */
		if ( t->dim().x() == widest ) x += PADDING;

		/* if root of next sibling is skinnier than what's immediately below it,
		 * then the arrow will be too short.  Add the diff between the extreme
		 * left-edge of the next siblings tree and the left-edge of the root
		 * token.
		 */
		fudge_factor = 0;
		if ( t->right() != NULL )
		{
			fudge_factor = widest_in_column((AST *)t->right())/2 -
						   atom_pt_width((AST *)t->right())/2;
		}

		if ( t->right() != NULL )
		{
			MOVE(x_old+widest/2+atom_pt_width(t)/2+PADDING, y+(ATOM_HEIGHT/2));
			LINE(x+fudge_factor-PADDING,y+(ATOM_HEIGHT/2));
			STROKE;
			RARROW(x+fudge_factor-PADDING,y+(ATOM_HEIGHT/2));
			widest = widest_in_column((AST *)t->right());
		}
	}
}
