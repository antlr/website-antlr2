/*
 * ltree.h -- defines needed for ltree.
 *
 * RIGHTS
 * 
 * Parr Research Corporation maintains the copyright on this software,
 * but any individual or company may use LTREE free of charge.  LTREE may
 * not be incorporated into commercial software or for commercial gain
 * without permission from Parr Research Corporation, but the postscript
 * output may be used for any purpose.  The source for LTREE may be
 * freely distributed as long as the headers and this README are
 * distributed along with the software and the files remain unmodified.
 * 
 * LTREE uses PCCTS, which is public-domain software developed by Parr
 * Research Corporation--some PCCTS files have been included.
 * 
 * WARRANTY
 * 
 * Parr Research Corporation makes no claims that this software does
 * anything useful, that it works, or even that it compiles.  "Your
 * mileage may vary."
 * 
 * Terence Parr
 * Parr Research Corporation
 * September 1995
 */

#ifndef ltree_h
#define ltree_h

#include <iostream.h>

/*
 * Define font as courier now because all one size--600 thousands of an
 * 'em' wide.  The width and height come out as REAL NUMBERS.
 */
#define TEXT_CHAR_HEIGHT ((int)(0.600 * PT_SIZE))
#define TEXT_CHAR_WIDTH ((int)(0.600 * PT_SIZE))

#define MAX_ATOM_SIZE 100
#define ATOM_HEIGHT TEXT_CHAR_HEIGHT		/* height in points */
#define PADDING 3			/* between line and atoms */
#define VERT_LINE_HEIGHT (2*TEXT_CHAR_HEIGHT+2)
#define HORIZ_LINE_WIDTH (2*TEXT_CHAR_WIDTH+2)

#define TREE_BOX_PADDING 10	/* padding to make BoundingBox bigger */

/* (width,height) of trees are in points */

class Tuple {
protected:
	int _x,_y;
public:
	Tuple()				{_x=_y=0;}
	Tuple(int a, int b)	{_x=a; _y=b;}
	int x()				{return _x;}
	int y()				{return _y;}
	void x(int a)		{_x=a;}
	void y(int a)		{_y=a;}
	void display()		{ cout << _x << " " << _y; }
	Tuple operator-(Tuple &a)
		{ Tuple t; t._x = this->_x - a._x; t._y = this->_y - a._y; return t; }
	Tuple operator+(Tuple &a)
		{ Tuple t; t._x = this->_x + a._x; t._y = this->_y + a._y; return t; }
/*	Tuple operator-(Tuple a)
		{ a._x = this->_x - a._x; a._y = this->_y - a._y; return a; }
	Tuple operator+(Tuple a)
		{ a._x = this->_x + a._x; a._y = this->_y + a._y; return a; }
*/
};

extern int PT_SIZE;			/* we assume Courier (const width) */

#include "tokens.h"
#include "LTREEParser.h"
typedef ANTLRCommonToken ANTLRToken;
#include "DLGLexer.h"
#include "PBlackBox.h"
#include "ATokPtr.h"
#include "ASTBase.h"
#include "AST.h"

#endif
