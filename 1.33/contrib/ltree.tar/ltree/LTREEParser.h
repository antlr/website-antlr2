/*
 * LTREEParser: P a r s e r  H e a d e r 
 *
 * Generated from: ltree.g
 *
 * Terence Parr, Russell Quong, Will Cohen, and Hank Dietz: 1989-1995
 * Parr Research Corporation
 * with Purdue University Electrical Engineering
 * with AHPCRC, University of Minnesota
 * ANTLR Version 1.32b7
 */

#ifndef LTREEParser_h
#define LTREEParser_h
class ASTBase;
#include "AParser.h"

class LTREEParser : public ANTLRParser {
protected:
	static ANTLRChar *_token_tbl[];
private:
	static SetWordType err1[4];
	static SetWordType err2[4];
	static SetWordType err3[4];
	static SetWordType setwd1[9];
private:
	void zzdflthandlers( int _signal, int *_retsignal );

public:
	LTREEParser(ANTLRTokenBuffer *input);
	void item(ASTBase **_root);
	void tree(ASTBase **_root);
	void element(ASTBase **_root);
	void atom(ASTBase **_root);
};

#endif /* LTREEParser_h */
