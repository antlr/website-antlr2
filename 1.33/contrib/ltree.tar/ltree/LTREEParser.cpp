/*
 * LTREEParser: P a r s e r  S u p p o r t
 *
 * Generated from: ltree.g
 *
 * Terence Parr, Russell Quong, Will Cohen, and Hank Dietz: 1989-1995
 * Parr Research Corporation
 * with Purdue University Electrical Engineering
 * with AHPCRC, University of Minnesota
 * ANTLR Version 1.32b7
 */

#include <stdio.h>
#define ANTLR_VERSION	132b7
#define ANTLR_SUPPORT_CODE
#include "tokens.h"
#include "LTREEParser.h"

ANTLRChar *LTREEParser::_token_tbl[]={
	/* 00 */	"Invalid",
	/* 01 */	"@",
	/* 02 */	"[\\ \\t]+",
	/* 03 */	"\\n",
	/* 04 */	"\\(",
	/* 05 */	"WORD",
	/* 06 */	"STRING",
	/* 07 */	"(nil|NIL)",
	/* 08 */	"\\)"
};

LTREEParser::LTREEParser(ANTLRTokenBuffer *input) : ANTLRParser(input,1,0,0,4)
{
	token_tbl = _token_tbl;
}

SetWordType LTREEParser::err1[4] = {0xe0,0x0,0x0,0x0};
SetWordType LTREEParser::err2[4] = {0xf0,0x0,0x0,0x0};
SetWordType LTREEParser::err3[4] = {0xe0,0x0,0x0,0x0};
SetWordType LTREEParser::setwd1[9] = {0x0,0x35,0x0,0x0,0x36,0x3e,0x3e,
	0x3e,0x34};
