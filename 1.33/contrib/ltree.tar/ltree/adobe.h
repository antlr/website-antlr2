/*
 * adobe.h -- Some Postscript defines
 *
 * RIGHTS
 * 
 * Parr Research Corporation maintains the copyright on this software,
 * but any individual or company may use LTREE free of charge.  LTREE may
 * not be incorporated into commercial software or for commercial gain
 * without permission from Parr Research Corporation, but the postscript
 * output may be used for any purpose.  The source for LTREE may be
 * freely distributed as long as the headers and this README are
 * distributed along with the software and the files remain unmodified.
 * 
 * LTREE uses PCCTS, which is public-domain software developed by Parr
 * Research Corporation--some PCCTS files have been included.
 * 
 * WARRANTY
 * 
 * Parr Research Corporation makes no claims that this software does
 * anything useful, that it works, or even that it compiles.  "Your
 * mileage may vary."
 * 
 * Terence Parr
 * Parr Research Corporation
 * September 1995
 */
#define  BASIC_HEADER	printf("%%!PS-Adobe-3.0\n")
#define  FM_REQD_HEADER	printf("%%!PS-Adobe-3.0 EPSF-3.0\n")	/* FrameMaker needs this one */
#define  BOUNDING_BOX(a,b,c,d)	\
						printf("%%%%BoundingBox: %d %d %d %d\n", a,b,c,d)
#define  MOVE(x,y)      printf("%d %d moveto\n", x, y)
#define  LINE(x,y)      printf("%d %d lineto\n", x, y)
#define  STROKE         printf("stroke\n")
#define  LABEL(S)       printf("%s %s\n", "%%Note:",S)

#define  THINLINES		printf("0.3 setlinewidth\n")
#define  ROTATE(th)		printf("%f rotate\n",th)
 
#define  RARROW(x,y)	printf("%d %d rarrow\n", x,y)
#define  DARROW(x,y)	printf("%d %d darrow\n", x,y)

#define  CIRCLE(x,y,r)	printf("%d %d %d 0 360 arc stroke\n", x,y,r)

#define  COURIER(pt)	printf("/Courier findfont\n%d scalefont setfont\n",pt)
#define  ITALICS(pt)	printf("/Times-Italic findfont\n%d scalefont setfont\n",pt)
#define  TEXT(_s,x,y)	printf("%d %d moveto\n(%s) show\n stroke\n", x,y,_s)

#define  XL     560   /* length in pixels for the X-axis */
#define  YL     400   /* length in pixels for the X-axis */
