/*
 * A n t l r  T r a n s l a t i o n  H e a d e r
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.32b7
 */
#include <stdio.h>
#define ANTLR_VERSION	132b7
#include "tokens.h"
#include "ASTBase.h"

#include "AParser.h"
#include "LTREEParser.h"
#include "DLexerBase.h"
#include "ATokPtr.h"
#ifndef PURIFY
#define PURIFY(r,s)
#endif

#include "ltree.h"

void
LTREEParser::item(ASTBase **_root)
{
	zzRULE;
	ASTBase **_astp, *_ast = NULL, *_sibling = NULL, *_tail = NULL;
	AST *_ast11=NULL;
	_ast = NULL;
	element(&_ast);
	if ( _tail==NULL ) _sibling = _ast; else _tail->setRight(_ast);
	_ast11 = (AST *)_ast;
	ASTBase::link(_root, &_sibling, &_tail);
	return;
fail:
	syn(zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk);
	resynch(setwd1, 0x1);
}

void
LTREEParser::tree(ASTBase **_root)
{
	zzRULE;
	ASTBase **_astp, *_ast = NULL, *_sibling = NULL, *_tail = NULL;
	ANTLRTokenPtr _t11=NULL,_t14=NULL;
	AST *_ast11=NULL,*_ast14=NULL;
	zzmatch(4); _t11 = (ANTLRTokenPtr)LT(1);

	  consume();
	{
		ANTLRTokenPtr _t21=NULL;
		AST *_ast21=NULL;
		if ( (LA(1)==WORD) ) {
			zzmatch(WORD); _t21 = (ANTLRTokenPtr)LT(1);

			
			_ast21 = new AST(_t21);
			_ast21->subroot(_root, &_sibling, &_tail);
			 consume();
		}
		else {
			if ( (LA(1)==STRING) ) {
				zzmatch(STRING); _t21 = (ANTLRTokenPtr)LT(1);

				
				_ast21 = new AST(_t21);
				_ast21->subroot(_root, &_sibling, &_tail);
				 consume();
			}
			else {
				if ( (LA(1)==7) ) {
					zzmatch(7); _t21 = (ANTLRTokenPtr)LT(1);

					  consume();
				}
				else {FAIL(1,err1,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
			}
		}
	}
	{
		AST *_ast21=NULL;
		while ( (setwd1[LA(1)]&0x2) ) {
			_ast = NULL;
			element(&_ast);
			if ( _tail==NULL ) _sibling = _ast; else _tail->setRight(_ast);
			_ast21 = (AST *)_ast;
			ASTBase::link(_root, &_sibling, &_tail);
		}
	}
	zzmatch(8); _t14 = (ANTLRTokenPtr)LT(1);

	  consume();
	return;
fail:
	syn(zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk);
	resynch(setwd1, 0x4);
}

void
LTREEParser::element(ASTBase **_root)
{
	zzRULE;
	ASTBase **_astp, *_ast = NULL, *_sibling = NULL, *_tail = NULL;
	AST *_ast11=NULL;
	if ( (setwd1[LA(1)]&0x8) ) {
		_ast = NULL;
		atom(&_ast);
		if ( _tail==NULL ) _sibling = _ast; else _tail->setRight(_ast);
		_ast11 = (AST *)_ast;
		ASTBase::link(_root, &_sibling, &_tail);
	}
	else {
		if ( (LA(1)==4) ) {
			_ast = NULL;
			tree(&_ast);
			if ( _tail==NULL ) _sibling = _ast; else _tail->setRight(_ast);
			_ast11 = (AST *)_ast;
			ASTBase::link(_root, &_sibling, &_tail);
		}
		else {FAIL(1,err2,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
	}
	return;
fail:
	syn(zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk);
	resynch(setwd1, 0x10);
}

void
LTREEParser::atom(ASTBase **_root)
{
	zzRULE;
	ASTBase **_astp, *_ast = NULL, *_sibling = NULL, *_tail = NULL;
	ANTLRTokenPtr _t11=NULL;
	AST *_ast11=NULL;
	if ( (LA(1)==WORD) ) {
		zzmatch(WORD); _t11 = (ANTLRTokenPtr)LT(1);

		
		_ast11 = new AST(_t11);
		_ast11->subchild(_root, &_sibling, &_tail);
		 consume();
	}
	else {
		if ( (LA(1)==STRING) ) {
			zzmatch(STRING); _t11 = (ANTLRTokenPtr)LT(1);

			
			_ast11 = new AST(_t11);
			_ast11->subchild(_root, &_sibling, &_tail);
			 consume();
		}
		else {
			if ( (LA(1)==7) ) {
				zzmatch(7); _t11 = (ANTLRTokenPtr)LT(1);

				
				_ast11 = new AST(_t11);
				_ast11->subchild(_root, &_sibling, &_tail);
				
				(*_root) = NULL;  
 consume();
			}
			else {FAIL(1,err3,&zzMissSet,&zzMissText,&zzBadTok,&zzBadText,&zzErrk); goto fail;}
		}
	}
	return;
fail:
	syn(zzBadTok, (ANTLRChar *)"", zzMissSet, zzMissTok, zzErrk);
	resynch(setwd1, 0x20);
}
