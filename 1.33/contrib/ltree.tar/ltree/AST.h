#ifndef AST_h
#define AST_h

#include "ltree.h"

class AST : public ASTBase {
protected:
	ANTLRTokenPtr token;
	Tuple _dim;
public:
	AST(ANTLRTokenPtr t) { token = t; }
	void preorder_action() {
		char *s = token->getText();
		printf(" %s", s);
	}
	char *getText() { return token->getText(); }
	Tuple &dim()	{ return _dim; }
	void dim(const Tuple &t)  { _dim = t; }
};

#endif
