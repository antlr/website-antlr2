/*
 * cccc_tok.h
 * definition of the token class interface for the cccc project
 *
 * $Log: cccc_tok.h,v $
 * Revision 1.1  1996/10/27 16:14:08  a4
 * Initial revision
 *
 * Revision 2.0  1996/09/17 12:04:20  a2
 * initial version for version 2 work
 *
 * Revision 2.0  1996/09/17 11:13:26  a2
 * *** empty log message ***
 *
 * Revision 1.1  1995/11/04 13:49:32  a4
 * Initial revision
 *
 */

#ifndef __CCCC_TOK_H
#define __CCCC_TOK_H

#include <iostream.h>
#include "AToken.h"
#include "cccc.h"

/*
** the counts to be used - tcLAST must be last to ensure allocation
** of the correct size matrix within ANTLRToken.
** The token count is maintained, but is not used at present.
*/
enum TokenCount { tcCOMLINES, tcCODELINES, tcTOKENS, tcMCCABES_VG, tcLAST };

/*
** The lexer uses nesting of braces ("{}") to try to identify external scope 
** for recovery purposes, and also to identify and count leading comments
** to an external object.  Nesting levels for square brackets and parentheses
** are also maintained in case they become useful.
*/
enum NestingType { ntBRACE, ntBRACK, ntPAREN, ntLAST };

/*
** the class definition for ANTLRToken
** Note that the name ANTLRToken is required to be either a class or a typedef
** by the PCCTS support code
*/
class ANTLRToken : public ANTLRCommonToken {
  static int RunningCount[tcLAST];
  static int RunningLevel[ntLAST];
  static int numAllocated;
  int CurrentCount[tcLAST];
  int CurrentLevel[ntLAST];
  friend ostream& operator << (ostream&,ANTLRToken&);
  friend class AST;
  friend class DLGLexer;
  void SetCounts();
  void CopyCounts(ANTLRToken& copyTok);
public:
  static int bCodeLine;

  ANTLRToken(ANTLRTokenType t, ANTLRChar *s);
  ANTLRToken(ANTLRToken& copyTok);
  ANTLRToken();
  ANTLRToken& operator=(ANTLRToken& copyTok);
  
  virtual ~ANTLRToken();

  virtual ANTLRAbstractToken *makeToken(
    ANTLRTokenType tt, ANTLRChar *txt, int line
  );

  static void IncrementCount(TokenCount tc) { 
    DbgMsg(COUNTER,cerr,"Incrementing count ");
    DbgMsg(COUNTER,cerr,tc);
    DbgMsg(COUNTER,cerr,endl);
    RunningCount[tc]++; 
  }
  static void IncrementNestingLevel(NestingType nt) { RunningLevel[nt]++; }
  static void DecrementNestingLevel(NestingType nt) { RunningLevel[nt]--; }
  int getCount(TokenCount tc) { return CurrentCount[tc]; }
  int getNestingLevel(NestingType nt) { return CurrentLevel[nt]; }
  void CountToken();
  char *getTokenTypeName();
  static void ZeroCounts() { 
    int i;
    for(i=0;i<tcLAST;i++) { RunningCount[i]=0; } 
    for(i=0;i<ntLAST;i++) { RunningLevel[i]=0; }
  }
};

ostream& operator << (ostream&, ANTLRToken&);

extern ANTLRToken currentLexerToken;


#endif
