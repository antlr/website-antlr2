#include "cccc_stg.h"


#ifdef UNIT_TEST

int main() {

  CCCC_String s0, s1("Hello"), s2("Dolly"), s3;
  s3=s1+"::"+s2;
  cout << s0 << " " << s1 << " " << s2 << " " << s3 << endl;

  cin >> s0 >> s1 >> s2 >> s3 ;
  cout << s0+"."+s1+"."+s2+"."+s3 << endl;


  return 0;
}
#endif