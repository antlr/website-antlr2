
#include "cccc_tbl.h"
#include "cccc_db.h"

#define LINE_BUFFER_SIZE 1000


template <class T, int size> CCCC_Table<T,size>::CCCC_Table() 
{
      max_records=size;
      ptr_array=new T*[size];
      number_of_records=0; 
}

template <class T, int size> CCCC_Table<T,size>::~CCCC_Table() 
{ 
  int i;
  for(i=0; i<number_of_records; i++) 
    { 
      delete ptr_array[i];
      ptr_array[i]=0;
    }
  delete[] ptr_array;
  ptr_array=0;
}

template<class T, int size> 
int CCCC_Table<T,size>::get_count(const char* count_tag) {
  int retval=0;
  int i;
  for(i=0; i<number_of_records; i++) 
{
    retval=retval+ptr_array[i]->get_count(count_tag);
  }
  return retval;
}

template<class T, int size> 
T* CCCC_Table<T,size>::find_or_insert(T* new_item_ptr)
{
  T *retval;
  int i=0;
  CCCC_String entity_key=new_item_ptr->key();
  while( 
	(i < number_of_records) && 
	strcmp(entity_key,ptr_array[i]->key()) 
	) 
    { 
      i++; 
    }

  // if we get to the end of the list, we need to insert a new item
  if(i == number_of_records) 
    {
      if(i==max_records) 
	{
	  retval=NULL;
	} 
      else 
	{
	  ptr_array[i]=new_item_ptr;
	  retval=new_item_ptr;
	  number_of_records++;
	}
    } 
  else 
    {
      retval=ptr_array[i];
    }

  return retval;
}

template <class T, int size> void CCCC_Table<T,size>::sort() {
  qsort(ptr_array,number_of_records,sizeof(T*),rank_by_string);
  int i;
  for(i=0; i<number_of_records; i++)
    {
      record_ptr(i)->sort();
    }
}



// explicit template instantiations
// this is done differently by different compilers
#ifdef OSF_TEMPLATES
#pragma define_template CCCC_Table<CCCC_Extent,10>
#pragma define_template CCCC_Table<CCCC_Module,1000> 
#pragma define_template CCCC_Table<CCCC_Member,1000> 
#pragma define_template CCCC_Table<CCCC_UseRelationship,100> 
#else
template class CCCC_Table<CCCC_Extent,10>;
template class CCCC_Table<CCCC_Module,1000>;
template class CCCC_Table<CCCC_Member,1000>;
template class CCCC_Table<CCCC_UseRelationship,100>;
#endif








