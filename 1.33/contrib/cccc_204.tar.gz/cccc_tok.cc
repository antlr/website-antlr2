/*
 * cccc_tok.C
 * implementation of a token class for the cccc project
 *
 * $Log: cccc_tok.cc,v $
 * Revision 1.3  1996/12/30 08:01:50  a5
 * working version
 * core dump still present
 * many other problems fixed
 *
 * Revision 1.1  1996/10/27 16:14:08  a4
 * Initial revision
 *
 * Revision 2.0  1996/09/17 12:04:20  a2
 * initial version for version 2 work
 *
 * Revision 2.0  1996/09/17 11:13:26  a2
 * *** empty log message ***
 *
 * Revision 1.3  1996/01/17 10:10:52  a1
 * Not quite sure what has changed here
 *
 * Revision 1.2  1995/11/12 11:01:18  a4
 * no report line output for items with blank canonical name
 *
 * Revision 1.1  1995/11/04  13:49:32  a4
 * Initial revision
 *
 */

#include "tokens.h"
#include "cccc_tok.h"
#include "Parser.h"

/* static variables */
int ANTLRToken::RunningCount[tcLAST];
int ANTLRToken::RunningLevel[ntLAST];
int ANTLRToken::bCodeLine;
int ANTLRToken::numAllocated=0;
int toks_alloc1=0, toks_alloc2=0, toks_alloc3=0, toks_freed=0;

ANTLRToken currentLexerToken;

/* 
** Token objects are used to count the occurences of states which 
** our analyser is interested in within the text.  Any metric which
** can be reduced to lexical counting on the text can be recorded
** this way.
**
** This implementation counts the following features:
**   tokens
**   comment lines
**   lines containing at least one token of code
**  
** It also makes a lexical count for the following tokens, each of which
** is expected to increase McCabe's cyclomatic complexity (Vg) for the 
** section of code by one unit:
**  IF FOR WHILE SWITCH BREAK RETURN ? && ||
**
** Note that && and || create additional paths through the code due to C/C++ 
** short circuit evaluation of logical expressions.
**
** Also note the way SWITCH constructs are counted: the desired increment
** in Vg is equal to the number of cases provided for, including the 
** default case, whether or not an action is defined for it.  This is acheived
** by counting the SWITCH at the head of the construct as a surrogate for 
** the default case, and counting BREAKs as surrogates for the individual
** cases.  This approach yields the correct results provided that the
** coding style in use ensures the use of BREAK after all non-default
** cases, and forbids 'drop through' from one case to another other than
** in the case where two or more values of the switch variable require
** identical actions, and no executable code is defined between the 
** case gates (as in the switch statement in ANTLRToken::CountToken() below).
*/

/* default constructor */
ANTLRToken::ANTLRToken() : ANTLRCommonToken() { 
  SetCounts(); 
  toks_alloc1++;
}

/* 
** constructor used by makeToken below 
*/
ANTLRToken::ANTLRToken(ANTLRTokenType t, ANTLRChar *s) : 
   ANTLRCommonToken(t,s) {
  setType(t);
  setText(s);
  SetCounts();
  CountToken();
  toks_alloc2++;
}

/* copy constructor */
ANTLRToken::ANTLRToken(ANTLRToken& copyTok) {
  setType(copyTok.getType());
  setText(copyTok.getText());
  setLine(copyTok.getLine());
  toks_alloc3++;
  CopyCounts(copyTok);
}

/* 
** the virtual pseudo-constructor 
** This is required because the PCCTS support code does not know the
** exact nature of the token which will be created by the user's code, 
** and indeed does not forbid the user creating more than one kind of
** token, so long as ANTLRToken is defined and all token classes are
** subclassed from ANTLRAbstractToken
*/
ANTLRAbstractToken *ANTLRToken::makeToken(
  ANTLRTokenType tt, ANTLRChar *txt, int line
) {
  DbgMsg(
    LEXER,cerr, 
    "makeToken(tt=>" << tt << 
      ", txt=>" << txt << 
      ",line=>" << line << ")" << endl
  );
  ANTLRToken *new_t = new ANTLRToken(tt,txt);
  if(new_t==0) { 
    cerr << "Memory overflow in "
     "ANTLRToken::makeToken(" << tt << "," << txt << "," << line << ")" << endl;
    exit(2);
  }
  new_t->setLine(line);
  return new_t;
}

/* the destructor */
ANTLRToken::~ANTLRToken() {
  toks_freed++;
  DbgMsg(MEMORY,cerr,"freeing token " << getText()
	 << " on line " << getLine()
	 << " c1:" << toks_alloc1 << " c2:" << toks_alloc2 
	 << " c3:" << toks_alloc3 << " freed:" << toks_freed << endl);
}

/* the assignment operator */
ANTLRToken& ANTLRToken::operator=(ANTLRToken& copyTok) {
  setType(copyTok.getType());
  setText(copyTok.getText());
  setLine(copyTok.getLine());
  CopyCounts(copyTok);
  return *this;
}

/*
** as each token is created, it receives a copy of the current running
** counts of each of the lexical metrics.  The counts for an extent of code
** are obtained by looking at the first and last tokens and identifying
** the differences in their count values
*/
void ANTLRToken::SetCounts() {
  int i;
  for(i=0; i < (int) tcLAST; i++) {
    CurrentCount[i]=RunningCount[i];
  }
  for(i=0; i< (int) ntLAST; i++) {
    CurrentLevel[i]=RunningLevel[i];
  }
}

/*
** used by the copy constructor
*/
void ANTLRToken::CopyCounts(ANTLRToken& copyTok) {
  int i;
  for(i=0; i < (int) tcLAST; i++) {
    CurrentCount[i]=copyTok.getCount(TokenCount(i));
  }
  for(i=0; i< (int) ntLAST; i++) {
    CurrentLevel[i]=copyTok.getNestingLevel(NestingType(i));
  }
}

/*
** ANTLRToken::CountToken performs counting of features which are traced
** back to individual tokens created up by the lexer, i.e. the token count 
** and McCabes VG.  Code lines and comment lines are both identified during
** the processing of text which the lexer will (usually) skip, so the code
** to increment these counts is in the relevant lexer rules in the file 
** cccc.g.m4
*/
void ANTLRToken::CountToken(){

  IncrementCount(tcTOKENS);
  bCodeLine=1;

  switch(_type) {
    case IF:
    case FOR:
    case WHILE:
    case SWITCH:
    case BREAK:
    case QUERY_OP:
    case LOGICAL_AND_OP:
    case LOGICAL_OR_OP:
    case RETURN:
      IncrementCount(tcMCCABES_VG);
    break;

    default:
      /* no additional action */ ;
  }
  DbgMsg(COUNTER,cerr,*this);
}

/* used for debugging */
char *ANTLRToken::getTokenTypeName() {
  return Parser::TokenName(getType());
}

/*
** structured output method for token objects
*/
ostream& operator << (ostream& out, ANTLRToken& t) {
  int i;

  out << "TOK: " << t.getTokenTypeName() << 
   " " << t.getText() <<
   " " << t.getLine();

  for(i=0; i<tcLAST; i++) {
    out << " " << t.getCount( TokenCount(i) );
  }

  for(i=0; i<ntLAST; i++) {
    out << " " << t.getNestingLevel( NestingType(i) );
  }

  out << endl;
  return out;
}
 
  
 
