#ifndef __CCCC_HTM_H
#define __CCCC_HTM_H
#include <fstream.h>
#include <iomanip.h>
#include <time.h>

#include "cccc_stg.h"
#include "cccc_db.h"
#include "cccc_met.h"

enum ReportType { 
  rtCONTENTS=0x01, rtSUMMARY=0x02, 
  rtPROC1=0x04, rtPROC2=0x08,
  rtSTRUCT1=0x10, rtSTRUCT2=0x20, 
  rtMETRICS=0x40, rtCCCC=0x80 
  // if we want any more we will need to send out for
  // more bits...
};

class CCCC_Html_Stream {
    friend CCCC_Html_Stream& operator <<(
      CCCC_Html_Stream& os, const CCCC_String& stg);
    friend CCCC_Html_Stream& operator <<(
      CCCC_Html_Stream& os, const CCCC_Metric& mtc);

    ofstream fstr;
    CCCC_String libdir;
    CCCC_Project& prj;
    time_t time_generated;

    void Table_Of_Contents(int report_mask);
    void Project_Summary();
    void Procedural_Summary();
    void Procedural_Detail();
    void Structural_Summary();
    void Structural_Detail();

    void Put_Section_Heading(
    	const CCCC_String& section_name,const CCCC_String& section_tag,
    	int section_level);
    void Put_Section_TOC_Entry(
      const CCCC_String& section_name, const CCCC_String& section_href,
      const CCCC_String& section_description);

    void Put_Header_Cell(const CCCC_String& label, int width=0);
    void Put_Label_Cell(
      const CCCC_String& label, int width=0,
      const CCCC_String& ref_name="", const CCCC_String& ref_href="");
    void Put_Metric_Cell(const CCCC_Metric& metric, int width=0);
    void Put_Metric_Cell(int count, const CCCC_String& tag, int width=0);
    void Put_Metric_Cell(
      int num, int denom, const CCCC_String& tag, int width=0);
    void Put_Extent_Cell(const CCCC_Extent& extent, int width=0);
    void Include_Library_File(char *filename);
public:
    CCCC_Html_Stream(
      CCCC_Project& project, const char* fname, 
      int report_mask, const char* libdir=".");
};

CCCC_Html_Stream& operator <<(CCCC_Html_Stream& os, const CCCC_String& stg);
CCCC_Html_Stream& operator <<(CCCC_Html_Stream& os, const CCCC_Metric& mtc);
CCCC_Html_Stream& operator <<(CCCC_Html_Stream& os, const CCCC_Extent& ext);
   
#endif /* __CCCC_HTM_H */


