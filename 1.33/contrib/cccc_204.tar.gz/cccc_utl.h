#ifndef __CCCC_UTL_H
#define __CCCC_UTL_H

#include <iostream.h>
#include "cccc_stg.h"

// this file declares all enumeration datatypes used in the project, and
// also the parse state class, which is used to capture information in the
// parse and transfer it to the code database for later report generation

// for each enumeration, a single character code is defined for each member
// these codes are shown in the inline comments

// the enumerations are designed to support resolution of incomplete 
// knowledge about several sections of code which relate to the same 
// object to give the most complete picture available

class AST;

enum Visibility { 
  vPUBLIC,vPROTECTED,vPRIVATE,vIMPLEMENTATION,  // 0123  (Booch/Rational Rose)
  vDONTKNOW,vDONTCARE,vINVALID                  // ?X* 
};
ostream& operator << (ostream&, Visibility);
istream& operator >> (istream&, Visibility&);

enum AugmentedBool { 
  abFALSE, abTRUE, abDONTKNOW, abDONTCARE, abINVALID // FT?X*
};
ostream& operator << (ostream& os, AugmentedBool ab);
istream& operator >> (istream& is, AugmentedBool& ab);

enum UseType { 
  utDECLARATION, utDEFINITION,          // Dd  of methods and classes
  utINHERITS,                           // I   normal inheritance
  utHASBYVAL, utHASBYREF,               // Hh  class data member
  utPARBYVAL, utPARBYREF,               // Pp  method parameter or return value
  utVARBYVAL, utVARBYREF,               // Vv  local variable within a method
  utTEMPLATE_NAME, utTEMPLATE_TYPE,     // Tt  for a typedef which aliases a
                                        //     template instantiation, 
                                        //     the name of the template and the
                                        //     type over which the template is
                                        //     instantiated
  utDONTKNOW, utDONTCARE, utINVALID     // ?X*                      
};
ostream& operator << (ostream&, UseType);
istream& operator >> (istream&, UseType&);

// the parse state object consists of a number of strings representing 
// knowledge about the identification of the source code object currently 
// being processed, a number of flags of type AugmentedBool, and 
// items representing knowledge about the 
// concerning the object's nature, and also its visibility

enum PSString { 
  pssFILE, pssRULE, pssFLAGS, // the context of the parse
  pssMODTYPE, pssMODULE,      // the syntactic class and name of the module 
  pssUTYPE,                    // unqualified type of the current member
  pssINDIR,                   // indirection associated with the type above
  pssITYPE,                   // type qualified with indirection
  pssMEMBER, pssPARAMS,       // name, parameter list of a member
  pssRELTYPE,                 // textual description of the relationship type
  pssLAST                     // used to dimension the array
};

enum PSFlag { 
  psfCONST, psfSTATIC, psfEXTERN, psfVIRTUAL, // AugmentedBool
  psfVISIBILITY,                              // Visibility
  psfLAST                                     // used to dimension the array
};
enum PSVerbosity { psvSILENT, psvQUIET, psvLOUD };

class ParseState {
  CCCC_String string[int(pssLAST)];
  char flag[int(psfLAST)];
  void insert_extent(ostream&, AST*, UseType);
public:
  ParseState();
  void reset();
  ParseState(const ParseState&);
  ParseState& operator=(const ParseState&);
  virtual ~ParseState();
  
  const CCCC_String& get_string(PSString) const;
  void set_string(PSString, const CCCC_String& value);
  int get_flag(PSFlag) const;
  void set_flag(PSFlag,int);
  void set_flag(Visibility);

  void dump(ostream&, PSVerbosity);      

  // each of the three functions below writes one or more records into 
  // the database of code
  void record_class_extent(AST*,UseType);
  void record_method_extent(AST*,UseType);
  void record_userel_extent(AST*,UseType);
  char *flags() { return flag; }
};

extern ParseState global_ps;

#endif










