#include <strstream.h>
#include "cccc_utl.h"
#include "cccc.h"
#include "cccc_db.h"
#include "cccc_ast.h"

#define FS "@"
#define RS "\n"

#define DEBUG_EXTENT_STREAMS
#ifdef DEBUG_EXTENT_STREAMS
ofstream cmod("cccc_mod.ext"), cmem("cccc_mem.ext"), cuse("cccc_use.ext");
#endif

// insertion and extraction functions intended to support enumerations

void insert_enum(ostream& os, int e, char *e_chars) { os << e_chars[e]; }

void extract_enum(istream& is, int& e, char *e_chars, int bad_value=0) {
  char c, *eptr=e_chars;
  is >> c;
  e=bad_value;
  while(*eptr != 0 && *eptr!=c) { eptr++; }
  if(*eptr==c) { 
    e=eptr-e_chars; 
  } else { 
    cerr << "bad enum character -"
	 << " got " << c
	 << " expected [" << e_chars << "]" << endl;
  } 
}


ostream& operator<<(ostream& os, AugmentedBool ab) {
  insert_enum(os,ab,"FT?X*");
  return os;
}

istream& operator>>(istream& is, AugmentedBool& ab) {
  extract_enum(is,(int&)ab,"FT?X*",abINVALID);
  return is;
}

ostream& operator<<(ostream& os, Visibility v) {
  insert_enum(os,v,"0123?X*");
  return os;
}

istream& operator>>(istream& is, Visibility& v) {
  extract_enum(is,(int&)v,"0123?X*",vINVALID);
  return is;
}

ostream& operator<<(ostream& os, UseType ut) {
  insert_enum(os,ut,"DdIHhPpVvTt?X*");
  return os;
}

istream& operator>>(istream& is, UseType& ut) {
  extract_enum(is,(int&)ut,"DdIHhPpVvTt?X*",utINVALID);
  return is;
}

ParseState::ParseState() { 
  reset();
}

void ParseState::reset() {
  int i;
  for(i=0;i<pssLAST;i++) { set_string(PSString(i),""); }
  for(i=0;i<psfLAST;i++) { flag[i]='?'; }
  flag[psfLAST]='\0';
}

  
ParseState::ParseState(const ParseState& ps) {
  *this=ps;
}

ParseState& ParseState::operator=(const ParseState& ps) {
  int i;
  for(i=0;i<pssLAST;i++) { 
    PSString pss=PSString(i);
    set_string(pss,ps.get_string(pss)); 
  }
  for(i=0;i<psfLAST;i++) { 
    flag[i]=ps.flag[i];
  }
  return *this;
}

ParseState::~ParseState() {}
  
const CCCC_String& ParseState::get_string(PSString pss) const { 
  return string[pss]; 
}
void  ParseState::set_string(PSString pss, const CCCC_String& value) { 
  string[pss]=value; 
}

int ParseState::get_flag(PSFlag psf) const {
  return int(flag[psf]); 
}

void ParseState::set_flag(PSFlag psf, int value) { 
  flag[psf]=value;
}

void ParseState::set_flag(Visibility value) { 
  MAKE_STRSTREAM(ofstr);
  ofstr << value;
  flag[psfVISIBILITY]=(ofstr.str())[0];
  RELEASE_STRSTREAM(ofstr);
}

void ParseState::dump(ostream& os, PSVerbosity psv){
  switch(psv) {
    case psvSILENT: 
      // do nothing
    break;

    case psvQUIET:
      // single line summary output
      os << "Signature: ";
      int i;
      for(i=0;i<pssLAST; i++) {
        CCCC_String sep;
        if(i==pssMODULE) { sep="::"; } else { sep=" "; }
        if(string[i]!="") { os << string[i] << sep; } 
      }
      os << "  Attributes: ";
      for(i=0; i<psfLAST; i++) {
        os<<flag[i];
      }
      os << endl;
    break;

    case psvLOUD:
      // verbose format
      os << "ModType:           " << string[pssMODTYPE] << endl;
      os << "Module:            " << string[pssMODULE] << endl;
      os << "Type:              " << string[pssITYPE] << endl;
      os << "Member:            " << string[pssMEMBER] << endl;
      os << "Params:            " << string[pssPARAMS] << endl;
      os << "Other attributes:" 
         << "  def: " << flag[psfVISIBILITY]
         << "  cst: " << flag[psfCONST]
         << "  stc: " << flag[psfSTATIC]
         << "  ext: " << flag[psfEXTERN]
         << "  vir: " << flag[psfVIRTUAL] << endl;
    break;

    default:
      cerr << "ParseState::dump() - illegal verbosity flag" << endl;
  }
}

void ParseState::insert_extent(ostream& os, AST* ast, UseType ut) {
  os << string[pssFILE] << "@"
     << ast->nStartLine() << "@" 
     << string[pssRELTYPE] << "@"
     << flags() << "@";

    // we add one to the LOC count as the last line counts, even though
    // the line separator occurs after the parser considers the
    // extent to have closed
    os << "LOC:" << ast->getCount(tcCODELINES) + 1
       << " COM:" << ast->getCount(tcCOMLINES) 
       << " MVG:" << ast->getCount(tcMCCABES_VG)
       << " TOK:" << ast->getCount(tcTOKENS);

    os << "@" << flag[psfVISIBILITY] << ut << ends;
}


  
void ParseState::record_class_extent(AST* ast, UseType ut ) {
    MAKE_STRSTREAM(str);
    str << string[pssMODULE] << "@" 
        << string[pssMODTYPE] << "@";
    insert_extent(str,ast,ut);
#ifdef DEBUG_EXTENT_STREAMS
if(DebugMask & EXTENT )
{
    cmod << str.str() << endl;
}
#endif
    prj->add_module(CONVERT_STRSTREAM(str));
    RELEASE_STRSTREAM(str);
}

void ParseState::record_method_extent(AST* ast, UseType ut ) {
    MAKE_STRSTREAM(str);
    str << string[pssMODULE] << "@" 
        << "" << "@"
        << string[pssMEMBER] << "@"
        << string[pssITYPE] << "@"
        << string[pssPARAMS] << "@"; 
    insert_extent(str,ast,ut);
#ifdef DEBUG_EXTENT_STREAMS
if(DebugMask & EXTENT )
{
    cmem << str.str() << endl;
}
#endif
    prj->add_member(CONVERT_STRSTREAM(str));
    RELEASE_STRSTREAM(str);
}

void ParseState::record_userel_extent(AST* ast, UseType ut) {
    // if pssMEMBER is not blank, we want to append it to pssRELTYPE
    if(strlen(string[pssMEMBER])>0)
    {
      MAKE_STRSTREAM(relstr);
      relstr << string[pssRELTYPE] << " [" << string[pssMEMBER] << "]" << ends;
      string[pssRELTYPE]=relstr.str();
      RELEASE_STRSTREAM(relstr);
    }

    // string[pssUTYPE] holds the name of the type of a parameter or return
    // value of a function, or the type of a member variable
    // if the unqualified type is blank, we map it to void
    // this is correct for parameters, wrong for return types (should be int)
    // but who really cares, as both are builtin types
    if(strlen(string[pssUTYPE])==0)
    {
      string[pssUTYPE]="void";
    }

    MAKE_STRSTREAM(str);
    str << string[pssMODULE] << "@" 
        << string[pssMEMBER] << "@"
        << string[pssUTYPE] << "@";
    insert_extent(str,ast,ut);
#ifdef DEBUG_EXTENT_STREAMS
if(DebugMask & EXTENT )
{
    cuse << str.str() << endl;
}
#endif
    prj->add_userel(CONVERT_STRSTREAM(str));
    RELEASE_STRSTREAM(str);
}

#ifdef UNIT_TEST

int main() {
  ParseState ps0, ps1, ps2, ps3, ps4, ps5;

  ps0.dump(cout,psvQUIET);
  ps0.dump(cout,psvLOUD);

  ps1.set_string(pssITYPE,"int");
  ps1.set_string(pssMODULE,"ParseState");
  ps1.set_string(pssMEMBER,"operation");
  ps1.set_string(pssPARAMS,"(int,int)");
  ps1.dump(cout, psvQUIET);
  ps1.dump(cout, psvLOUD);

  ps2=ps1;
  ps2.set_string(pssPARAMS,"");
  ps2.set_visibility(vIMPLEMENTATION);
  ps2.set_flag(psfVIRTUAL,abTRUE);
  ps2.dump(cout,psvQUIET);
  ps2.dump(cout,psvLOUD);

  ps3=ps2;
  ps3.set_string(pssMODULE,"");
  ps3.set_flag(psfCONST,abDONTKNOW);
  ps3.dump(cout,psvQUIET);
  ps3.dump(cout,psvLOUD);

  return 0;
}

#endif /* UNIT_TEST */









